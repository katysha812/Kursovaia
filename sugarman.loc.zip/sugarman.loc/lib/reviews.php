<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['id'])) {
    header('Location: /login.php');
    exit();
}

// Проверяем, есть ли у пользователя заказы
$user_id = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT COUNT(*) as order_count FROM заказы WHERE id_пользователя = ?");
$stmt->execute([$user_id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result['order_count'] == 0) {
    die('У вас нет заказов для оставления отзыва');
}

// Обработка загрузки фото
$photoPath = null;
if (!empty($_FILES['photo']['name'])) {
    $uploadDir = 'uploads/reviews/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $filename = 'review_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $targetFile = $uploadDir . $filename;
    
    if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
        $photoPath = $targetFile;
    }
}

// Добавление отзыва в БД
try {
    $stmt = $pdo->prepare("
        INSERT INTO отзывы 
            (id_пользователя, Заголовок, Содержание, Фото) 
        VALUES 
            (?, ?, ?, ?)
    ");
    $stmt->execute([
        $user_id,
        $_POST['title'],
        $_POST['content'],
        $photoPath
    ]);
    
    header('Location: /reviews.php?success=1');
    exit();
    
} catch (PDOException $e) {
    die("Ошибка при добавлении отзыва: " . $e->getMessage());
}
?>