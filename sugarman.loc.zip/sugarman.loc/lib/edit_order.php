<?php
session_start();
require_once '../lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    die(json_encode(['error' => 'Вы не авторизованы']));
}

// Получаем роль
$stmt = $pdo->prepare("SELECT id_роли FROM пользователи WHERE id = ?");
$stmt->execute([$_SESSION['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!in_array($user['id_роли'], [2, 3])) {
    die(json_encode(['error' => 'У вас нет прав для редактирования заявок']));
}

// Валидация данных
$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$status = isset($_POST['status']) ? intval($_POST['status']) : 0;

if ($order_id <= 0 || $status <= 0) {
    die(json_encode(['error' => 'Неверные параметры запроса']));
}

// Поля, которые будем обновлять
$fields = ['id_статус_заявки = ?'];
$params = [$status];

// Если админ – возможность обновить другие поля
if ($user['id_роли'] == 3) {
    $weight = isset($_POST['weight']) ? floatval(str_replace(',', '.', $_POST['weight'])) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $address = isset($_POST['address']) ? intval($_POST['address']) : 0;
    $comment = isset($_POST['comment']) ? trim(filter_var($_POST['comment'], FILTER_SANITIZE_SPECIAL_CHARS)) : '';

    // Валидация дополнительных полей
    if ($weight <= 0 || $quantity <= 0 || $address <= 0) {
        die(json_encode(['error' => 'Неверные параметры запроса']));
    }

    $fields[] = 'вес = ?';
    $fields[] = 'количество = ?';
    $fields[] = 'примечания = ?';
    $fields[] = 'id_адрес_доставки = ?';
    $params[] = $weight;
    $params[] = $quantity;
    $params[] = $comment;
    $params[] = $address;
}

$params[] = $order_id;

try {
    $sql = "UPDATE заявки SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    header('Location: ../Orders.php?success=1');
    exit;
} catch (PDOException $e) {
    die(json_encode(['error' => 'Ошибка базы данных: ' . $e->getMessage()]));
}
?>