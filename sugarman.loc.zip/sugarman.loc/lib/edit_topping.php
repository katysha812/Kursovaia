<?php
session_start();
require_once '../lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    header('Location: ../login.php');
    exit;
}

// Проверяем права доступа
$userId = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT id_роли FROM Пользователи WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!in_array($user['id_роли'], [2, 3])) {
    die("Доступ запрещён");
}

// Обрабатываем данные
$начинкаId = intval($_POST['id']);
$название = trim(filter_var($_POST['name'], FILTER_SANITIZE_SPECIAL_CHARS));
$описание = trim(filter_var($_POST['description'], FILTER_SANITIZE_SPECIAL_CHARS));

// Обрабатываем загрузку нового фото
$фото = $_POST['currentPhoto'] ?? null;

if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    if (in_array($ext, $allowed)) {
        $newFileName = uniqid('topping_', true) . '.' . pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/' . $newFileName);
        $фото = 'uploads/' . $newFileName;
    } else {
        die("Неверный формат изображения");
    }
}

// Обновляем запись в базе
$stmt = $pdo->prepare("UPDATE начинки SET название = ?, описание = ?, фото = ? WHERE id = ?");
$stmt->execute([$название, $описание, $фото, $начинкаId]);

header('Location: ../toppings.php');
exit;
?>