<?php
session_start();

// Получаем данные из формы
$first_name = trim(filter_var($_POST['user_first_name'], FILTER_SANITIZE_SPECIAL_CHARS));
$name = trim(filter_var($_POST['user_name'], FILTER_SANITIZE_SPECIAL_CHARS));

$number = filter_var($_POST['user_number'], FILTER_SANITIZE_NUMBER_INT);

if (strlen($number) !== 10 && strlen($number) !== 11) {
    echo "Неверный формат телефона";
    exit;
}

$email = trim(filter_var($_POST['user_email'], FILTER_VALIDATE_EMAIL));
$dateborn = trim(filter_var($_POST['user_dateborn'], FILTER_SANITIZE_SPECIAL_CHARS));
$adress_id = intval($_POST['user_adress']);
$nickname = trim(filter_var($_POST['user_nickname'], FILTER_SANITIZE_SPECIAL_CHARS));
$password = trim(filter_var($_POST['user_password'], FILTER_SANITIZE_SPECIAL_CHARS));

// Проверки
if (strlen($password) < 3 || strlen($password) > 100) {
    echo "Пароль должен быть от 3 до 100 символов!";
    exit;
}

if (strlen($nickname) < 2 || strlen($nickname) > 15) {
    echo "Никнейм должен быть от 2 до 15 символов!";
    exit;
}

if (strlen($name) < 2) {
    echo "Имя должно быть больше 2 символов!";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Введите корректную почту!";
    exit;
}

if ($adress_id <= 0) {
    echo "Выберите корректный адрес!";
    exit;
}

// Хэширование пароля
$salt = "72398?%№2_оывша8448";
$password = md5($salt . $password);

// Подключение к БД
require "db.php";

// Вставка данных
$sql = 'INSERT INTO Пользователи(id_роли, имя, фамилия, никнейм, id_адреса, телефон, почта, пароль, дата_рождения)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
$stmt = $pdo->prepare($sql);
$stmt->execute([1, $name, $first_name, $nickname, $adress_id, $number, $email, $password, $dateborn]);

// Перенаправление
header('Location: ../Login.php');
exit;
?>