<?php
session_start();

$nickname = trim(filter_var($_POST['user_nickname'], FILTER_SANITIZE_SPECIAL_CHARS));
$password = trim(filter_var($_POST['user_password'], FILTER_SANITIZE_SPECIAL_CHARS));

if (strlen($password) < 3) {
    echo "Пароль должен быть больше 3 символов!";
    exit;
} elseif (strlen($password) > 100) {
    echo "Пароль должен быть меньше 100 символов!";
    exit;
}

if (strlen($nickname) < 2 || strlen($nickname) > 15) {
    echo "Никнейм должен быть больше 2 и меньше 15 символов!";
    exit;
}

require "db.php";

$sql = "
    SELECT 
        u.id,
        u.id_роли,
        u.имя,
        u.фамилия,
        u.никнейм,
        u.телефон,
        u.почта,
        u.дата_рождения,
        u.id_адреса,
        a.Номер_дома,
        s.название AS улица,
        c.название AS город,
        u.пароль
    FROM пользователи u
    LEFT JOIN адреса a ON u.id_адреса = a.id
    LEFT JOIN улицы s ON a.id_улицы = s.id
    LEFT JOIN города c ON s.id_города = c.id
    WHERE u.никнейм = ?
";

$query = $pdo->prepare($sql);
$query->execute([$nickname]);

if ($query->rowCount() == 0) {
    echo "Неверный никнейм или пароль";
    exit;
}

$user = $query->fetch(PDO::FETCH_ASSOC);
$valid_password = false;

if (password_verify($password, $user['пароль'])) {
    $valid_password = true;
} 
else {
    $salt = "72398?%№2_оывша8448";
    $hashed_password = md5($salt . $password);
    
    if ($hashed_password === $user['пароль']) {
        $valid_password = true;
        
        $new_hash = password_hash($password, PASSWORD_DEFAULT);
        $update_stmt = $pdo->prepare("UPDATE пользователи SET пароль = ? WHERE id = ?");
        $update_stmt->execute([$new_hash, $user['id']]);
    }
}

if (!$valid_password) {
    echo "Неверный пароль";
    exit;
}

if (!empty($user['дата_рождения'])) {
    $date = new DateTime($user['дата_рождения']);
    $formatted_date = $date->format('d.m.Y');
} else {
    $formatted_date = '';
}

$_SESSION['id'] = $user['id'];
$_SESSION['id_роли'] = $user['id_роли'];
$_SESSION['имя'] = $user['имя'];
$_SESSION['фамилия'] = $user['фамилия'];
$_SESSION['никнейм'] = $user['никнейм'];
$_SESSION['телефон'] = $user['телефон'];
$_SESSION['почта'] = $user['почта'];
$_SESSION['дата_рождения'] = $formatted_date;
$_SESSION['город'] = $user['город'] ?? '';
$_SESSION['улица'] = $user['улица'] ?? '';
$_SESSION['номер_дома'] = $user['Номер_дома'] ?? '';

header('Location: ../User.php');
exit;
?>