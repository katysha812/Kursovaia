<?php
session_start();

if (!isset($_SESSION['id'])) {
    header('Location: ../Login.php');
    exit();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/lib/db.php';

$stmt = $pdo->prepare("SELECT id_роли FROM пользователи WHERE id = ?");
$stmt->execute([$_SESSION['id']]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$userData || ($userData['id_роли'] != 2 && $userData['id_роли'] != 3)) {
    $_SESSION['error'] = "У вас нет прав для удаления отзывов";
    header('Location: /Reviews.php');
    exit();
}

if (!isset($_POST['review_id'])) {
    $_SESSION['error'] = "Не указан отзыв для удаления";
    header('Location: /Reviews.php');
    exit();
}

$review_id = $_POST['review_id'];

try {
    $sql = "DELETE FROM отзывы WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$review_id]);

    $_SESSION['success'] = "Отзыв успешно удален";
    header('Location: /Reviews.php');
    exit();

} catch (PDOException $e) {
    error_log("Ошибка при удалении отзыва: " . $e->getMessage());
    $_SESSION['error'] = "Произошла ошибка при удалении отзыва";
    header('Location: /Reviews.php');
    exit();
}