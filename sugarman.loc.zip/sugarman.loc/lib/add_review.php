<?php
session_start();

if (!isset($_SESSION['id'])) {
    header('Location: ../Login.php');
    exit();
}

require_once __DIR__ . '/db.php';

$user_id = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT COUNT(*) as order_count FROM заявки WHERE id_пользователя = ?");
$stmt->execute([$user_id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result['order_count'] == 0) {
    $_SESSION['error'] = "У вас нет завершенных заказов для написания отзыва";
    header('Location: /Reviews.php');
    exit();
}

$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
$photo_path = '';

if (empty($title) || empty($content)) {
    $_SESSION['error'] = "Заголовок и содержание отзыва обязательны для заполнения";
    header('Location: /Reviews.php');
    exit();
}

if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $file_info = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($file_info, $_FILES['photo']['tmp_name']);
    
    if (in_array($mime_type, $allowed_types)) {
        $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/uploads/reviews/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $filename = uniqid('review_') . '.' . $extension;
        $destination = $upload_dir . $filename;
        
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
            $photo_path = '/uploads/reviews/' . $filename;
        }
    }
}

try {
    $sql = "INSERT INTO отзывы (id_пользователя, Заголовок, Содержание, Фото, Дата) 
            VALUES (?, ?, ?, ?, NOW())";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $user_id,
        htmlspecialchars($title),
        htmlspecialchars($content),
        $photo_path
    ]);
    
    $_SESSION['success'] = "Отзыв успешно добавлен!";
    header('Location: /Reviews.php');
    exit();
    
} catch (PDOException $e) {
    error_log("Ошибка при добавлении отзыва: " . $e->getMessage());
    $_SESSION['error'] = "Произошла ошибка при добавлении отзыва";
    header('Location: /Reviews.php');
    exit();
}