<?php
session_start();
require_once '../lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    header('Location: ../login.php');
    exit;
}

// Проверяем права доступа
$userId = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT id_роли FROM Пользователи WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!in_array($user['id_роли'], [2, 3])) {
    die("Доступ запрещён");
}

// Обработка загрузки формы
$название = trim(filter_var($_POST['name'], FILTER_SANITIZE_SPECIAL_CHARS));
$описание = trim(filter_var($_POST['description'], FILTER_SANITIZE_SPECIAL_CHARS));

// Обработка загрузки фото
$фото = null;
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp','svg'];
    
    if (in_array($ext, $allowed)) {
        $newFileName = uniqid('topping_', true) . '.' . $ext;
        move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/' . $newFileName);
        $фото = 'uploads/' . $newFileName;
    } else {
        die("Неверный формат изображения");
    }
}

// Добавляем в БД
$stmt = $pdo->prepare("INSERT INTO начинки (название, описание, фото) VALUES (?, ?, ?)");
$stmt->execute([$название, $описание, $фото]);

header('Location: ../toppings.php');
exit;
?>