<?php
session_start();
require_once '../lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    die(json_encode(['error' => 'Вы не авторизованы']));
}

// Проверяем роль
$stmt = $pdo->prepare("SELECT id_роли FROM пользователи WHERE id = ?");
$stmt->execute([$_SESSION['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user['id_роли'] != 2) {
    die(json_encode(['error' => 'У вас нет прав для удаления заявок']));
}

// Валидация данных
$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;

if ($order_id <= 0) {
    die(json_encode(['error' => 'Неверные параметры запроса']));
}

try {
    // Удаляем заявку
    $stmt = $pdo->prepare("DELETE FROM заявки WHERE id = ?");
    $stmt->execute([$order_id]);
    
    header('Location: ../Orders.php?success=1');
    exit;
} catch (PDOException $e) {
    die(json_encode(['error' => 'Ошибка базы данных: ' . $e->getMessage()]));
}
?>