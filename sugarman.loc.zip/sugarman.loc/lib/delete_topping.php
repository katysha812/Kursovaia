<?php
session_start();
require_once '../lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    header('Location: ../login.php');
    exit;
}

// Проверяем права доступа
$userId = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT id_роли FROM Пользователи WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!in_array($user['id_роли'], [2, 3])) {
    die("Доступ запрещён");
}

// Удаляем начинку
$начинкаId = intval($_POST['id']);
$stmt = $pdo->prepare("DELETE FROM начинки WHERE id = ?");
$stmt->execute([$начинкаId]);

header('Location: ../toppings.php');
exit;
?>