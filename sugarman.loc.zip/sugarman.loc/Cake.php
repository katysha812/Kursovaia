<?php
session_start();
require_once 'lib/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Некорректный запрос");
}

$id = intval($_GET['id']);

// Получаем данные пользователя
$пользователь = null;
if (isset($_SESSION['id'])) {
    $stmt = $pdo->prepare("SELECT имя, фамилия, телефон, почта FROM пользователи WHERE id = ?");
    $stmt->execute([$_SESSION['id']]);
    $пользователь = $stmt->fetch(PDO::FETCH_ASSOC);
}

function formatPhoneDisplay($phone) {
    if (empty($phone)) return '';
    $phone = preg_replace('/\D/', '', $phone);
    if (preg_match('/^(\d)(\d{3})(\d{3})(\d{2})(\d{2})$/', $phone, $matches)) {
        return "+{$matches[1]}({$matches[2]}){$matches[3]}-{$matches[4]}-{$matches[5]}";
    }
    return $phone;
}

// Получаем данные о торте
$stmt = $pdo->prepare("SELECT id, фото, название, описание, цена_кг FROM торты WHERE id = ?");
$stmt->execute([$id]);
$торт = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$торт) {
    die("Торт не найден");
}

// Получаем все торты для навигации
$stmt = $pdo->query("SELECT id, название FROM торты ORDER BY id");
$все_торты = $stmt->fetchAll(PDO::FETCH_ASSOC);
$ids = array_column($все_торты, 'id');
$названия = array_column($все_торты, 'название', 'id');

$key = array_search($id, $ids);
$предыдущий_id = ($key > 0) ? $ids[$key - 1] : end($ids);
$следующий_id = ($key < count($ids) - 1) ? $ids[$key + 1] : reset($ids);

// Получаем начинки
$stmt = $pdo->query("SELECT id, название FROM начинки");
$все_начинки = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем адреса
$stmt = $pdo->query("
    SELECT a.id, g.название AS город, u.название AS улица, a.Номер_дома
    FROM адреса a
    JOIN улицы u ON a.id_улицы = u.id
    JOIN города g ON u.id_города = g.id
");
$адреса = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Проверяем первый ли это заказ пользователя
$первый_заказ = false;
if (isset($_SESSION['id'])) {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM заявки WHERE id_пользователя = ?");
    $stmt->execute([$_SESSION['id']]);
    $первый_заказ = ($stmt->fetchColumn() == 0);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($торт['название']) ?></title>
    <link rel="stylesheet" href="css/main.css" type="text/css"/>
    <link rel="stylesheet" href="css/cake.css" type="text/css"/>
    <link rel="stylesheet" href="css/popup.css" type="text/css"/>
    <link rel="stylesheet" href="css/footer.css" type="text/css"/>
</head>
<body>
<div class="wrapper">
    <?php require_once "blocks/header.php"; ?>

    <div class="cake-detail container">
        <div class="cake-image">
            <img src="<?= htmlspecialchars($торт['фото'] ?? 'assets/images/PicCake.svg') ?>" alt="<?= htmlspecialchars($торт['название']) ?>">
        </div>

        <div class="cake-info">
            <h2><?= htmlspecialchars($торт['название']) ?></h2>
            <p><?= htmlspecialchars($торт['описание']) ?></p>
            <p><strong>Цена за кг:</strong> <?= number_format($торт['цена_кг'], 2, '.', '') ?> ₽</p>
            <?php if (isset($_SESSION['id'])): ?>
                <button class="btn" id="open_pop_up">Оформить заявку</button>
            <?php else: ?>
                <a href="Registration.php" class="btn">Зарегистрироваться</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="cake-navigation">
        <a href="cake.php?id=<?= $предыдущий_id ?>" class="nav-link prev">
            &larr; <?= htmlspecialchars($названия[$предыдущий_id]) ?>
        </a>
        <a href="cake.php?id=<?= $следующий_id ?>" class="nav-link next">
            <?= htmlspecialchars($названия[$следующий_id]) ?> &rarr;
        </a>
    </div>

    <div class="pop_up" id="pop_up">
        <div class="pop_up_container">
            <div class="pop_up_body">
                <p>Заявка на торт</p>
                <form method="post" action="lib/order.php">
                    <input type="hidden" name="торт" value="<?= $торт['id'] ?>">

                    <div class="forms">
                        <div class="form-column">
                            <input type="text" name="имя" placeholder="Имя" value="<?= htmlspecialchars($пользователь['имя'] ?? '') ?>" readonly>
                            <input type="text" name="фамилия" placeholder="Фамилия" value="<?= htmlspecialchars($пользователь['фамилия'] ?? '') ?>" readonly>
                            <input type="email" name="почта" placeholder="Почта" value="<?= htmlspecialchars($пользователь['почта'] ?? '') ?>" readonly>
                            <label for="телефон">Телефон для обратной связи:</label>
                            <input type="tel" name="телефон" id="телефон"
                                   placeholder="+7(XXX)XXX-XX-XX"
                                   value="<?= !empty($пользователь['телефон']) ? htmlspecialchars(formatPhoneDisplay($пользователь['телефон'])) : '' ?>" readonly>
                            <label for="дата_мероприятия">К какой дате хотите получить торт?:</label>
                            <input type="date" name="дата_мероприятия" required>
                            <label for="примечание">Дополнительные пожелания:</label>
                            <input type="text" name="примечание" placeholder="Примечание">
                        </div>
                        <div class="form-column">
                            <select name="начинка" required>
                                <option value="">Выберите начинку</option>
                                <?php foreach ($все_начинки as $начинка): ?>
                                    <option value="<?= htmlspecialchars($начинка['id']) ?>">
                                        <?= htmlspecialchars($начинка['название']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <select name="адрес_доставки" required>
                                <option value="">Выберите адрес доставки</option>
                                <?php foreach ($адреса as $адрес): ?>
                                    <option value="<?= htmlspecialchars($адрес['id']) ?>">
                                        <?= htmlspecialchars("{$адрес['город']}, ул. {$адрес['улица']}, д. {$адрес['Номер_дома']}") ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <div class="weight-field">
                                <label for="вес">Вес (Кг):</label>
                                <input type="number" name="вес" min="0.3" max="25" step="0.1" placeholder="Вес" required>
                            </div>

                            <label for="количество">Количество:</label>
                            <input type="number" name="количество" min="1" step="1" placeholder="Количество" required>

                            <div class="cost-field">
                                <label for="стоимость" id="cost-label">
                                    <?= $первый_заказ ? 'Стоимость (скидка за первый заказ)' : 'Стоимость' ?>
                                </label>
                                <input type="text" id="стоимость" name="стоимость" readonly>
                            </div>
                        </div>
                    </div>

                    <button type="submit">Отправить заявку</button>
                </form>
                <div class="pop_up_close" id="close_pop_up">&#10006;</div>
            </div>
        </div>
    </div>
</div>

<?php require_once "blocks/footer.php"; ?>

<script src="js/index.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const weightInput = document.querySelector('input[name="вес"]');
    const quantityInput = document.querySelector('input[name="количество"]');
    const costInput = document.getElementById('стоимость');
    const cakePrice = <?= $торт['цена_кг'] ?>;

    function calculateCost() {
        const weight = parseFloat(weightInput.value) || 0;
        const quantity = parseInt(quantityInput.value) || 0;
        let totalCost = cakePrice * weight * quantity;

        <?php if ($первый_заказ): ?>
            totalCost *= 0.9; // 10% скидки
        <?php endif; ?>

        costInput.value = totalCost.toFixed(2) + ' ₽';
    }

    weightInput.addEventListener('input', calculateCost);
    quantityInput.addEventListener('input', calculateCost);
});
</script>
</body>
</html>