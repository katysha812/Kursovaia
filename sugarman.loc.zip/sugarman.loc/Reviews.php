<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/lib/db.php';

try {
    $sql = "
        SELECT 
            o.id,
            o.Заголовок,
            o.Содержание,
            o.Фото,
            o.Дата,
            p.имя,
            p.фамилия,
            p.никнейм
        FROM отзывы o
        LEFT JOIN пользователи p ON o.id_пользователя = p.id
        ORDER BY o.Дата DESC
    ";
    $stmt = $pdo->query($sql);
    $отзывы = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении отзывов: " . $e->getMessage());
}

$hasOrders = false;
$isAdmin = false;
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];
    
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as order_count FROM заявки WHERE id_пользователя = ?");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $hasOrders = ($result['order_count'] > 0);
    } catch (PDOException $e) {
        $hasOrders = false;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT id_роли FROM пользователи WHERE id = ?");
        $stmt->execute([$user_id]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        $isAdmin = ($userData && ($userData['id_роли'] == 2 || $userData['id_роли'] == 3));
    } catch (PDOException $e) {
        $isAdmin = false;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отзывы</title>
    <link rel="stylesheet" href="css/main.css" type="text/css"/>
    <link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <link rel="stylesheet" href="css/reviews.css" type="text/css"/>
    <link rel="stylesheet" href="css/footer.css" type="text/css"/>
    <link rel="stylesheet" href="css/popup.css" type="text/css"/>
    <style>
        .pop_up {
            width: 100%;
            height: 100%;
            position: fixed;
            left: 0;
            top: 0;
            background-color: rgba(0, 0, 0, .8);
            z-index: 999;
            transition: opacity 0.3s ease;
            opacity: 0;
            display: none;
        }
        
        .pop_up.active {
            display: block;
            opacity: 1;
        }
        
        .pop_up_container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
        
        .pop_up_body {
            position: relative;
            max-width: 700px;
            width: 90%;
            background-color: #FEF6EF;
            border-radius: 20px;
            padding: 30px;
            margin: auto;
        }
        
        .pop_up_body p {
            color: #DA627D;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .pop_up_close {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #DA627D;
            font-weight: bold;
        }
        
        .pop_up_body input,
        .pop_up_body textarea {
            width: 100%;
            margin-bottom: 20px;
            padding: 17px 20px;
            background: #fcedde;
            border-radius: 10px;
            border: 3px solid #e9a8b2;
            font-weight: 400;
            font-size: 18px;
            color: #DA627D;
            outline: none;
            font-family: 'Inter', sans-serif;
            box-sizing: border-box;
        }
        
        .pop_up_body textarea {
            min-height: 163px;
            resize: vertical;
        }
        
        .pop_up_body input::placeholder,
        .pop_up_body textarea::placeholder {
            color: #ED8494;
            opacity: 1;
        }
        
        .pop_up_body button {
            cursor: pointer;
            display: block;
            width: 250px;
            margin: 15px auto 0 auto;
            border: 0;
            color: #FEF6EF;
            background-color: #DA627D;
            transition: all 500ms ease;
            border-radius: 50px;
            padding: 10px 10px;
            font-size: 18px;
            font-weight: 700;
        }
        
        .pop_up_body button:hover {
            background: #ED8494;
        }
        
        .btn-delete {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        
        .btn-delete:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/blocks/header.php'; ?>
        
        <!-- Отзывы -->
        <div class="container-reviews">
            <!-- Заголовок и кнопка начинок -->
            <div class="title-reviews">
                <h2>Отзывы</h2>
            </div>
            
            <!-- Обертка для карточек -->
            <div class="cards-reviews">
                <?php foreach ($отзывы as $отзыв): ?>
                    <div class="card-reviews">
                        <div class="block1">
                            <h5><?= date('d.m.Y, H:i', strtotime($отзыв['Дата'])) ?></h5>
                            <h3><?= htmlspecialchars($отзыв['Заголовок']) ?></h3>
                            <p><?= htmlspecialchars($отзыв['Содержание']) ?></p>

                            <!-- Информация о пользователе -->
                            <div class="user-info">
                                <h6><?= htmlspecialchars($отзыв['имя'] . ' ' . $отзыв['фамилия']) ?></h6>
                                <h4>@<?= htmlspecialchars($отзыв['никнейм'] ?? 'пользователь') ?></h4>
                            </div>

                            <!-- Кнопка удаления отзыва (по центру карточки) -->
                            <?php if ($isAdmin): ?>
                                <form method="post" action="lib/delete_review.php" onsubmit="return confirm('Вы уверены, что хотите удалить этот отзыв?')" class="delete-review-form">
                                    <input type="hidden" name="review_id" value="<?= $отзыв['id'] ?>">
                                    <button type="submit" class="btn-delete">Удалить отзыв</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Кнопка в зависимости от статуса пользователя -->
            <?php if ($hasOrders): ?>
                <button class="btn" id="open_review_popup">Оставить отзыв</button>
            <?php else: ?>
                <button class="btn"><a href="Contacts.php">Связаться с нами</a></button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Попап для добавления отзыва -->
    <div class="pop_up" id="review_popup">
        <div class="pop_up_container">
            <div class="pop_up_body">
                <p>Добавить отзыв</p>
                <form method="post" action="lib/add_review.php" enctype="multipart/form-data">
                    <input type="text" name="title" placeholder="Заголовок отзыва" required>
                    <textarea name="content" placeholder="Текст отзыва" required></textarea>
                    <label for="photo" style="display: block; text-align: left; margin-bottom: 10px; color: #DA627D; font-weight: bold;">
                        Фото (необязательно):
                    </label>
                    <input type="file" name="photo" accept="image/*" style="margin-bottom: 25px;">
                    <button type="submit">Отправить отзыв</button>
                </form>
                <div class="pop_up_close" id="close_review_popup">&#10006</div>
            </div>
        </div>
    </div>

    <div class="wrapper2">
        <!-- Контакты -->
        <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/blocks/cont.php'; ?>
    </div>
    
    <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/blocks/footer.php'; ?>
    
    <style>
    .card-reviews .delete-review-form {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .btn-delete {
        background-color: #f44336; 
        color: white;
        border: none;
        padding: 10px 15px;
        font-size: 16px;
        border-radius: 50px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        width: auto;
        text-align: center;
    }

    .btn-delete:hover {
        background-color: #d32f2f;
    }
    </style>


    <script>
        document.getElementById('open_review_popup').addEventListener('click', function() {
            document.getElementById('review_popup').classList.add('active');
        });

        document.getElementById('close_review_popup').addEventListener('click', function() {
            document.getElementById('review_popup').classList.remove('active');
        });
        
        document.addEventListener('click', function(e) {
            const popup = document.getElementById('review_popup');
            if (popup.classList.contains('active') && e.target === popup) {
                popup.classList.remove('active');
            }
        });
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.getElementById('review_popup').classList.remove('active');
            }
        });
    </script>
</body>
</html>