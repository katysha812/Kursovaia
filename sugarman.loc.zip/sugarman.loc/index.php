<?php
session_start();
require_once 'lib/db.php';

// Получаем данные пользователя
$пользователь = null;
if (isset($_SESSION['id'])) {
    $stmt = $pdo->prepare("SELECT имя, фамилия, телефон, почта FROM пользователи WHERE id = ?");
    $stmt->execute([$_SESSION['id']]);
    $пользователь = $stmt->fetch(PDO::FETCH_ASSOC);
}

function formatPhone($phone) {
    if (empty($phone)) return '';
    $phone = preg_replace('/\D/', '', $phone);
    if (preg_match('/^(\d)(\d{3})(\d{3})(\d{2})(\d{2})$/', $phone, $matches)) {
        return "+{$matches[1]}({$matches[2]}){$matches[3]}-{$matches[4]}-{$matches[5]}";
    }
    return $phone;
}

// Получаем данные для страницы
try {
    // Начинки
    $stmt = $pdo->query("SELECT id, название, фото, описание FROM начинки WHERE id IN (1, 4, 6) ORDER BY FIELD(id, 4, 1, 6)");
    $начинки = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Торты
    $stmt = $pdo->query("SELECT id, название, фото, описание, цена_кг FROM торты WHERE id IN (1, 2, 6, 7) ORDER BY FIELD(id, 1, 7, 6, 2)");
    $торты = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Все торты для формы
    $stmt = $pdo->query("SELECT id, название, цена_кг FROM торты");
    $все_торты = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Все начинки для формы
    $stmt = $pdo->query("SELECT id, название FROM начинки");
    $все_начинки = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Адреса
    $stmt = $pdo->query("
        SELECT a.id, g.название AS город, u.название AS улица, a.Номер_дома
        FROM адреса a
        JOIN улицы u ON a.id_улицы = u.id
        JOIN города g ON u.id_города = g.id
    ");
    $адреса = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Отзывы
    $stmt = $pdo->query("
        SELECT o.id, o.Заголовок, o.Содержание, o.Фото, p.имя, p.фамилия, p.никнейм
        FROM отзывы o
        LEFT JOIN пользователи p ON o.id_пользователя = p.id
        WHERE o.id IN (1, 3)
        ORDER BY FIELD(o.id, 1, 3)
    ");
    $отзывы = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Проверяем первый ли это заказ пользователя
    $первый_заказ = false;
    if (isset($_SESSION['id'])) {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM заявки WHERE id_пользователя = ?");
        $stmt->execute([$_SESSION['id']]);
        $первый_заказ = ($stmt->fetchColumn() == 0);
    }
} catch (PDOException $e) {
    die("Ошибка при получении данных: " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная</title>
    <Link rel="stylesheet" href="css/main.css" type="text/css"/>
    <Link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <Link rel="stylesheet" href="css/offer.css" type="text/css"/>
    <Link rel="stylesheet" href="css/toppings.css" type="text/css"/>
    <Link rel="stylesheet" href="css/statistic.css" type="text/css"/>
    <Link rel="stylesheet" href="css/slogan.css" type="text/css"/>
    <Link rel="stylesheet" href="css/reviews.css" type="text/css"/>
    <Link rel="stylesheet" href="css/popup.css" type="text/css"/>
    <Link rel="stylesheet" href="css/customcakes.css" type="text/css"/>
    <Link rel="stylesheet" href="css/footer.css" type="text/css"/>
</head>
<body>
    <div class="wrapper">
        <?php require_once "blocks/header.php"; ?>

        <div class="hero container">
            <div class="hero--info">
                <h1>Десерты, которые исцелят вашу сладкую душу</h1>
                <p>Каждое наше изделие — это не просто десерт, а маленькое произведение искусства, созданное с любовью и вниманием к деталям. Попробуйте — и почувствуете разницу.</p>
                <?php if (isset($_SESSION['id'])): ?>
                    <button class="btn" id="open_pop_up">Оформить заявку</button>
                <?php else: ?>
                    <a href="Registration.php" class="btn">Зарегистрироваться</a>
                <?php endif; ?>
            </div>
            <img src="" alt="Слайды картинок" id="hero-image">
        </div>

        <div class="pop_up" id="pop_up">
            <div class="pop_up_container">
                <div class="pop_up_body">
                    <p>Заявка на торт</p>
                    <form method="post" action="lib/order.php">
                        <div class="forms">
                            <div class="form-column">
                                <input type="text" name="имя" placeholder="Имя" value="<?= htmlspecialchars($пользователь['имя'] ?? '') ?>" readonly>
                                <input type="text" name="фамилия" placeholder="Фамилия" value="<?= htmlspecialchars($пользователь['фамилия'] ?? '') ?>" readonly>
                                <input type="email" name="почта" placeholder="Почта" value="<?= htmlspecialchars($пользователь['почта'] ?? '') ?>" readonly>
                                <label for="телефон">Телефон для обратной связи:</label>
                                <input type="tel" name="телефон" id="телефон"
                                    placeholder="+7 (XXX) XXX-XX-XX"
                                    value="<?= !empty($пользователь['телефон']) ? htmlspecialchars(formatPhone($пользователь['телефон'])) : '' ?>" readonly>
                                <label for="дата_мероприятия">К какой дате хотите получить торт?:</label>
                                <input type="date" name="дата_мероприятия" required>
                                <label for="примечание">Дополнительные пожелания:</label>
                                <input type="text" name="примечание" placeholder="Примечание">
                            </div>
                            <div class="form-column">
                                <select name="начинка" required>
                                    <option value="">Выберите начинку</option>
                                    <?php foreach ($все_начинки as $начинка): ?>
                                        <option value="<?= htmlspecialchars($начинка['id']) ?>">
                                            <?= htmlspecialchars($начинка['название']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <select name="торт" id="торт" required>
                                    <option value="">Выберите дизайн торта</option>
                                    <?php foreach ($все_торты as $торт): ?>
                                        <option value="<?= htmlspecialchars($торт['id']) ?>" data-цена="<?= htmlspecialchars($торт['цена_кг']) ?>">
                                            <?= htmlspecialchars($торт['название']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <select name="адрес_доставки" required>
                                    <option value="">Выберите адрес доставки</option>
                                    <?php foreach ($адреса as $адрес): ?>
                                        <option value="<?= htmlspecialchars($адрес['id']) ?>">
                                            <?= htmlspecialchars("{$адрес['город']}, ул. {$адрес['улица']}, д. {$адрес['Номер_дома']}") ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <div class="weight-field">
                                    <label for="вес">Вес (Кг):</label>
                                    <input type="number" name="вес" min="0.3" max="25" step="0.1" placeholder="Вес" required>
                                </div>

                                <label for="количество">Количество:</label>
                                <input type="number" name="количество" min="1" step="1" placeholder="Количество" required>

                                <div class="cost-field">
                                    <label for="стоимость" id="cost-label">
                                        <?= $первый_заказ ? 'Стоимость (скидка за первый заказ)' : 'Стоимость' ?>
                                    </label>
                                    <input type="text" id="стоимость" name="стоимость" readonly>
                                </div>
                            </div>
                        </div>
                        <button type="submit">Отправить заявку</button>
                    </form>
                    <div class="pop_up_close" id="close_pop_up">&#10006;</div>
                </div>
            </div>
        </div>
        <!-- Начинки -->
        <div class="container-toppings">
            <!-- Заголовок и кнопка начинок -->
            <div class="title-toppings">
                <h2>Новые начинки</h2>
                <a href="Toppings.php" class="see-all">Посмотреть все</a>
            </div>
            
            <!-- Обертка для карточек -->
            <div class="cards-toppings">
                <?php foreach ($начинки as $начинка): ?>
                <div class="card-topping">
                    <div class="block">
                        <img src="<?php echo htmlspecialchars($начинка['фото'] ?? 'assets/images/PicToppings.svg'); ?>" alt="<?php echo htmlspecialchars($начинка['название'] ?? 'Название начинки'); ?>">
                        <h3><?php echo htmlspecialchars($начинка['название'] ?? 'Название начинки'); ?></h3>
                        <p><?php echo htmlspecialchars($начинка['описание'] ?? 'Описание начинки'); ?></p>
                    </div>
                </div>

                <?php endforeach; ?>
            </div>
            
            <!-- Текст под карточками -->
            <div class="toppings-text">
                <p>Стоимость начинки входит в стоимость дизайна!</p>
            </div>
        </div>
        <!-- Предложение о заказе -->
        <div class="offer container">
            <div class="card-offer container">
                <div class="offer-content">
                <img src="assets/images/PicOffer.svg" alt="">
                <div class="text-offer">

                    <?php if (isset($_SESSION['id'])): ?>
                        <?php if ($первый_заказ): ?>
                            <!-- Сообщение о скидке на первый заказ -->
                            <h3>Благодарим за регистрацию!</h3>
                            <p>Вам доступна скидка <strong>10%</strong> на первый заказ!</p>
                            <button class="btn" id="open_pop_up_promo">Оформить заказ со скидкой</button>
                        <?php else: ?>
                            <!-- Сообщение о новинках для постоянных клиентов -->
                            <h3>Попробуйте наши новинки!</h3>
                            <p>Попробуйте наши новые начинки одним из первых! Оформите заказ прямо сейчас!</p>
                            <button class="btn" id="open_pop_up_promo">Заказать</button>
                        <?php endif; ?>

                    <?php else: ?>
                        <!-- Стандартное предложение для гостей -->
                        <h3>Скидка за регистрацию на сайте!</h3>
                        <p>Зарегистрируйтесь и получите скидку на первый заказ в размере 10% от стоимости!</p>
                        <button class="btn" id="open_reg"><a href="Registration.php">Зарегистрироваться</a></button>
                    <?php endif; ?>

                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="wrapper2">
        <!-- Отзывы -->
        <div class="statistic-container">
            <h1>Отзывы</h1>
            <div class="cards-statistics"> <!-- Контейнер для карточек отзывов -->

                <?php foreach ($отзывы as $отзыв): ?>
                    <div class="card-statistic"> <!-- Карточка отзыва -->
                        <div class="pic-user">
                            <!-- Фото пользователя -->
                            <img src="<?= htmlspecialchars($отзыв['Фото'] ?? 'assets/images/DefaultReviewPhoto.svg') ?>" alt="Фото пользователя">

                            <!-- Имя Фамилия -->
                            <h3><?= htmlspecialchars($отзыв['имя'] ?? 'Имя') ?> <?= htmlspecialchars($отзыв['фамилия'] ?? 'Фамилия') ?></h3>

                            <!-- Никнейм -->
                            <p>@<?= htmlspecialchars($отзыв['никнейм'] ?? 'пользователь') ?></p>
                        </div>

                        <div class="text-statistic">
                            <!-- Заголовок отзыва -->
                            <h2><?= htmlspecialchars($отзыв['Заголовок']) ?></h2>

                            <!-- Текст отзыва -->
                            <p><?= htmlspecialchars($отзыв['Содержание']) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
        </div>
    </div>
    <div class="wrapper">
        <!-- Популярные торты или хиты -->
        <div class="container-cakes">
            <h1>Популярные торты или хиты</h1>
            
             <div class="cards-cakes">
            <?php foreach ($торты as $торт): ?>
            <div class="card-cake">
                <div class="cake block">
                    <img src="<?php echo htmlspecialchars($торт['фото'] ?? 'assets/images/PicCake.svg'); ?>" 
                         alt="<?php echo htmlspecialchars($торт['название'] ?? 'Торт'); ?>">
                    <h3><?php echo htmlspecialchars($торт['название'] ?? 'Название торта'); ?></h3>
                    <p><?php echo htmlspecialchars($торт['описание'] ?? 'Описание торта'); ?></p>
                    <a href="CustomCakes.php">
                        <button class="btn">Посмотреть все</button>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
        </div>
    </div>

    <div class="wrapper2">
        <!-- Контакты -->
        <?php require_once "blocks/cont.php"; ?>
    </div>
    <?php require_once "blocks/footer.php"; ?>

    <script src="js/index.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const weightInput = document.querySelector('input[name="вес"]');
        const quantityInput = document.querySelector('input[name="количество"]');
        const cakeSelect = document.getElementById('торт');
        const costInput = document.getElementById('стоимость');

        function calculateCost() {
            const selectedCakePrice = parseFloat(cakeSelect.options[cakeSelect.selectedIndex]?.getAttribute('data-цена') || 0);
            const weight = parseFloat(weightInput.value) || 0;
            const quantity = parseInt(quantityInput.value) || 0;
            let totalCost = selectedCakePrice * weight * quantity;

            <?php if ($первый_заказ): ?>
                totalCost *= 0.9; // 10% скидки
            <?php endif; ?>

            costInput.value = totalCost.toFixed(2) + ' ₽';
        }

        weightInput.addEventListener('input', calculateCost);
        quantityInput.addEventListener('input', calculateCost);
        cakeSelect.addEventListener('change', calculateCost);
    });
    </script>
</body>
</html>