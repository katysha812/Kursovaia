<?php
session_start();
require_once 'lib/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_user') {
    $имя = trim(filter_var($_POST['имя'], FILTER_SANITIZE_SPECIAL_CHARS));
    $фамилия = trim(filter_var($_POST['фамилия'], FILTER_SANITIZE_SPECIAL_CHARS));
    $никнейм = trim(filter_var($_POST['никнейм'], FILTER_SANITIZE_SPECIAL_CHARS));
    $телефон = preg_replace('/\D/', '', $_POST['телефон']);
    $почта = filter_var($_POST['почта'], FILTER_SANITIZE_EMAIL);
    $дата_рождения = $_POST['дата_рождения'];
    $id_адреса = intval($_POST['адрес_доставки']);
    $id_роли = intval($_POST['id_роли']);
    
    if ($_POST['пароль'] !== $_POST['пароль_confirm']) {
        $error = "Пароли не совпадают!";
    } else {
        $пароль = password_hash($_POST['пароль'], PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO пользователи (имя, фамилия, никнейм, телефон, почта, дата_рождения, id_адреса, id_роли, пароль) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$имя, $фамилия, $никнейм, $телефон, $почта, $дата_рождения, $id_адреса, $id_роли, $пароль]);
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        } catch (PDOException $e) {
            $error = "Ошибка при добавлении пользователя: " . $e->getMessage();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_user') {
    $id = intval($_POST['user_id']);
    $имя = trim(filter_var($_POST['имя'], FILTER_SANITIZE_SPECIAL_CHARS));
    $фамилия = trim(filter_var($_POST['фамилия'], FILTER_SANITIZE_SPECIAL_CHARS));
    $никнейм = trim(filter_var($_POST['никнейм'], FILTER_SANITIZE_SPECIAL_CHARS));
    $телефон = preg_replace('/\D/', '', $_POST['телефон']);
    $почта = filter_var($_POST['почта'], FILTER_SANITIZE_EMAIL);
    $дата_рождения = $_POST['дата_рождения'];
    $id_адреса = intval($_POST['адрес_доставки']);
    $id_роли = intval($_POST['id_роли']);

    try {
        $stmt = $pdo->prepare("UPDATE пользователи SET 
                              имя = ?, фамилия = ?, никнейм = ?, телефон = ?, 
                              почта = ?, дата_рождения = ?, id_адреса = ?, id_роли = ?
                              WHERE id = ?");
        $stmt->execute([$имя, $фамилия, $никнейм, $телефон, $почта, $дата_рождения, $id_адреса, $id_роли, $id]);
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } catch (PDOException $e) {
        $error = "Ошибка при обновлении пользователя: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $id = intval($_POST['user_id']);
    
    try {
        $stmt = $pdo->prepare("DELETE FROM пользователи WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } catch (PDOException $e) {
        $error = "Ошибка при удалении пользователя: " . $e->getMessage();
    }
}

$stmt = $pdo->query("
    SELECT 
        u.id, u.имя, u.фамилия, u.никнейм, u.телефон, u.почта, 
        u.дата_рождения, u.id_роли, r.название AS роль,
        a.id AS id_адреса, g.название AS город, ul.название AS улица, a.Номер_дома
    FROM пользователи u
    LEFT JOIN роли r ON u.id_роли = r.id
    LEFT JOIN адреса a ON u.id_адреса = a.id
    LEFT JOIN улицы ul ON a.id_улицы = ul.id
    LEFT JOIN города g ON ul.id_города = g.id
    ORDER BY u.id DESC
");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->query("
    SELECT a.id, g.название AS город, u.название AS улица, a.Номер_дома
    FROM адреса a
    JOIN улицы u ON a.id_улицы = u.id
    JOIN города g ON u.id_города = g.id
");
$addresses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->query("SELECT id, название FROM роли");
$roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

function formatPhone($phone) {
    if (empty($phone)) return '';
    $phone = preg_replace('/\D/', '', $phone);
    if (preg_match('/^(\d)(\d{3})(\d{3})(\d{2})(\d{2})$/', $phone, $matches)) {
        return "+{$matches[1]}({$matches[2]}){$matches[3]}-{$matches[4]}-{$matches[5]}";
    }
    return $phone;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление пользователями</title>
    <link rel="stylesheet" href="css/main.css" type="text/css"/>
    <link rel="stylesheet" href="css/statistic.css" type="text/css"/>
    <link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <link rel="stylesheet" href="css/footer.css" type="text/css"/>
    <link rel="stylesheet" href="css/registration.css" type="text/css"/>
    <link rel="stylesheet" href="css/popup.css" type="text/css"/>
    <link rel="stylesheet" href="css/users.css" type="text/css"/>
</head>
<body>
<div class="wrapper">
    <?php require_once "blocks/header.php"; ?>
</div>
<div class="wrapper3">
    <div class="statistic-container">
        <h4>Добавить нового пользователя</h4>
        <div class="container-registration">
            <?php if (!empty($error)): ?>
                <div class="error-message"><?= $error ?></div>
            <?php endif; ?>
            <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <input type="hidden" name="action" value="add_user">
                
                <div class="inline">
                    <div>
                        <label>Имя</label>
                        <input type="text" name="имя" required>
                    </div>
                    <div>
                        <label>Фамилия</label>
                        <input type="text" name="фамилия">
                    </div>
                </div>

                <div class="inline">
                    <div>
                        <label>Никнейм</label>
                        <input type="text" name="никнейм" required>
                    </div>
                    <div>
                        <label>Роль</label>
                        <select name="id_роли" required>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['название']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <label>Телефон</label>
                <input type="tel" name="телефон" id="phone" placeholder="+7 (XXX) XXX-XX-XX" required>

                <label>Почта</label>
                <input type="email" name="почта" required>

                <label>Дата рождения</label>
                <input type="date" name="дата_рождения">

                <label>Адрес доставки</label>
                <select name="адрес_доставки" required>
                    <option value="">Выберите адрес</option>
                    <?php foreach ($addresses as $address): ?>
                        <option value="<?= $address['id'] ?>">
                            <?= htmlspecialchars("{$address['город']}, ул. {$address['улица']}, д. {$address['Номер_дома']}") ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <div class="inline">
                    <div>
                        <label>Пароль</label>
                        <input type="password" name="пароль" required>
                    </div>
                    <div>
                        <label>Подтвердите пароль</label>
                        <input type="password" name="пароль_confirm" required>
                    </div>
                </div>

                <button type="submit">Добавить пользователя</button>
            </form>
        </div>
    </div>
</div>
<div class="wrapper">
    <div class="statistic-container">
        <h1>Список пользователей</h1>

        <div class="cards-statistics">
            <?php if (empty($users)): ?>
                <p>Нет пользователей.</p>
            <?php else: ?>
                <?php foreach ($users as $user): ?>
                    <div class="card-statistic">
                        <div class="pic-user">
                            <h3><?= htmlspecialchars($user['имя']) ?> <?= htmlspecialchars($user['фамилия']) ?></h3>
                            <p>@<?= htmlspecialchars($user['никнейм']) ?></p>
                            <p><b><?= htmlspecialchars($user['роль']) ?></b></p>
                        </div>
                        <div class="text-statistic">
                            <p><strong>ID:</strong> <?= $user['id'] ?></p>
                            <p><strong>Телефон:</strong> <?= formatPhone($user['телефон']) ?></p>
                            <p><strong>Почта:</strong> <?= htmlspecialchars($user['почта']) ?></p>
                            <p><strong>Дата рождения:</strong> <?= htmlspecialchars($user['дата_рождения']) ?></p>
                            <p><strong>Адрес:</strong> 
                                <?= $user['город'] ? htmlspecialchars("{$user['город']}, ул. {$user['улица']}, д. {$user['Номер_дома']}") : 'Не указан' ?>
                            </p>

                            <div class="user-actions">
                                <button class="btn-edit" onclick="openEditPopup(
                                    <?= $user['id'] ?>,
                                    '<?= addslashes($user['имя']) ?>',
                                    '<?= addslashes($user['фамилия']) ?>',
                                    '<?= addslashes($user['никнейм']) ?>',
                                    '<?= addslashes($user['телефон']) ?>',
                                    '<?= addslashes($user['почта']) ?>',
                                    '<?= addslashes($user['дата_рождения']) ?>',
                                    <?= $user['id_адреса'] ?>,
                                    <?= $user['id_роли'] ?>
                                )">
                                    Редактировать
                                </button>
                                <button class="btn-delete" onclick="confirmDelete(<?= $user['id'] ?>)">Удалить</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="pop_up" id="edit_user_popup">
    <div class="pop_up_container">
        <div class="pop_up_body">
            <div class="pop_up_close" onclick="closeEditPopup()">×</div>
            <h2>Редактировать пользователя</h2>
            <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <input type="hidden" name="action" value="update_user">
                <input type="hidden" name="user_id" id="edit_user_id">

                <div class="forms">
                    <div class="form-column">
                        <div class="form-group">
                            <label for="edit_имя">Имя:</label>
                            <input type="text" name="имя" id="edit_имя" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_фамилия">Фамилия:</label>
                            <input type="text" name="фамилия" id="edit_фамилия">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_никнейм">Никнейм:</label>
                            <input type="text" name="никнейм" id="edit_никнейм" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_дата_рождения">Дата рождения:</label>
                            <input type="date" name="дата_рождения" id="edit_дата_рождения">
                        </div>
                    </div>
                    
                    <div class="form-column">
                        <div class="form-group">
                            <label for="edit_телефон">Телефон:</label>
                            <input type="tel" name="телефон" id="edit_телефон" 
                                placeholder="+7(XXX)XXX-XX-XX" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_почта">Почта:</label>
                            <input type="email" name="почта" id="edit_почта" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_адрес_доставки">Адрес доставки:</label>
                            <select name="адрес_доставки" id="edit_адрес_доставки" required>
                                <option value="">Выберите адрес</option>
                                <?php foreach ($addresses as $address): ?>
                                    <option value="<?= $address['id'] ?>">
                                        <?= htmlspecialchars("{$address['город']}, ул. {$address['улица']}, д. {$address['Номер_дома']}") ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_id_роли">Роль:</label>
                            <select name="id_роли" id="edit_id_роли" required>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['название']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-save">Сохранить изменения</button>
            </form>
        </div>
    </div>
</div>

<form id="delete_form" method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" style="display: none;">
    <input type="hidden" name="action" value="delete_user">
    <input type="hidden" name="user_id" id="delete_user_id">
</form>

<?php require_once "blocks/footer.php"; ?>

<script src="js/users.js"></script>
</body>
</html>