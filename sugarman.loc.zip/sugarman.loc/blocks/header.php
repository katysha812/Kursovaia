<?php
session_start();

$current_page = basename($_SERVER['PHP_SELF'], '.php');

require_once $_SERVER['DOCUMENT_ROOT'] . '/lib/db.php';

$is_logged_in = isset($_SESSION['id']);
$role = null;

if ($is_logged_in) {
    $stmt = $pdo->prepare("SELECT id_роли FROM Пользователи WHERE id = ?");
    $stmt->execute([$_SESSION['id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $role = $user['id_роли'];
}
?>
<header class="container">
    <a href="AboutUs.php" class="logo-link">
        <div class="logo-container">
            <img src="assets/images/logoIcon.svg" alt="" class="logo-img">
            <span class="logo">Сахарный человек</span>
        </div>
    </a>
    <nav>
        <ul>
            <li<?= ($current_page == 'index') ? ' class="active"' : '' ?>><a href="index.php">Главная</a></li>
            <li<?= ($current_page == 'AboutUs') ? ' class="active"' : '' ?>><a href="AboutUs.php">О нас</a></li>
            <li<?= ($current_page == 'CustomCakes') ? ' class="active"' : '' ?>><a href="CustomCakes.php">Торты на заказ</a></li>
            <li<?= ($current_page == 'Toppings') ? ' class="active"' : '' ?>><a href="Toppings.php">Начинки</a></li>
            <li<?= ($current_page == 'Reviews') ? ' class="active"' : '' ?>><a href="Reviews.php">Отзывы</a></li>
            <li<?= ($current_page == 'Contacts') ? ' class="active"' : '' ?>><a href="Contacts.php">Контакты</a></li>

            <?php if ($is_logged_in): ?>
                <li<?= ($current_page == 'Orders') ? ' class="active"' : '' ?>>
                    <a href="Orders.php">Заявки</a>
                </li>
            <?php endif; ?>

            <?php if ($is_logged_in && $role =3): ?>
                <li<?= ($current_page == 'Users') ? ' class="active"' : '' ?>>
                    <a href="Users.php">Пользователи</a>
                </li>
            <?php endif; ?>

            <!-- Профиль / Вход -->
            <?php if ($is_logged_in): ?>
                <li class="<?= ($current_page == 'User') ? 'btn active' : 'btn' ?>">
                    <a href="User.php">Профиль</a>
                </li>
            <?php else: ?>
                <li class="<?= ($current_page == 'Login') ? 'btn active' : 'btn' ?>">
                    <a href="Login.php">Войти</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</header>