<div class="contacts-container">
    <h1>Контакты</h1>

    <div class="info-contacts">

        <div class="contact-text">
            <h3>Часы работы:</h3>
            <p>Пн-Вс: с 10:00 до 21:00</p>
        </div>

        <div class="contact-text">
            <h3>Почта:</h3>
            <p>
                <a class="contact-link" href="https://mail.google.com/">
                    mail-company@mail.ru
                </a>
            </p>
        </div>

        <div class="contact-text">
            <h3>Мы находимся по адресу:</h3>
            <p>
                <a class="contact-link" href="https://yandex.ru/maps/1095/abakan/?ll=91.442387%2C53.721152&z=13" target="_blank">
                    г. Город, ул Уличная, дом 0, корп 0, офис 0
                </a>
            </p>
        </div>

        <div class="contact-text">
            <h3>Телефон:</h3>
            <p>
                <a class="contact-link" href="tel:+70000000000">
                    +7 (000) 000-000-00
                </a>
            </p>
        </div>

    </div>

    <a href="AboutUs.php" class="logo-link">
        <div class="logo-contacts">
            <img src="assets/images/logoIcon2.svg" alt="Логотип Сахарный человек">
            <div class="logo-text">
                <h2>Сахарный человек</h2>
                <p>Торты на заказ</p>
            </div>
        </div>
    </a>
    
</div>