document.addEventListener('DOMContentLoaded', function () {
        const imageElement = document.getElementById('about-us-image');
        const images = [
            'assets/images/AboutUsPic1.svg',
            'assets/images/AboutUsPic2.svg',
            'assets/images/AboutUsPic3.svg',
            'assets/images/AboutUsPic4.svg',
            'assets/images/AboutUsPic5.svg',
            'assets/images/AboutUsPic6.svg',
            'assets/images/AboutUsPic7.svg'
        ];

        let currentIndex = 0;

        // Функция для обновления изображения
        function updateImage() {
            // Сначала делаем изображение прозрачным
            imageElement.style.opacity = 0;

            // Устанавливаем новый путь к изображению
            setTimeout(() => {
                imageElement.src = images[currentIndex];
                imageElement.style.opacity = 1; // Включаем прозрачность после изменения src
            }, 500); // Задержка в 500 мс для плавного исчезновения старого изображения

            // Переходим к следующему индексу
            currentIndex = (currentIndex + 1) % images.length;
        }

        // Запускаем первое изображение сразу при загрузке страницы
        updateImage();

        // Автоматическая смена изображений каждые 5 секунд
        setInterval(updateImage, 5000); // 5000 мс = 5 секунд
    });