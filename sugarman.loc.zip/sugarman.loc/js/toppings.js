function openEditPopup(data) {
    document.getElementById('popup_edit_id').value = data.id;
    document.getElementById('popup_edit_name').value = data.название;
    document.getElementById('popup_edit_description').value = data.описание;

    const currentPhoto = document.getElementById('popup_current_photo');
    currentPhoto.src = data.фото || 'assets/images/PicToppings.svg';
    currentPhoto.alt = data.название;

    document.getElementById('edit_popup').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeEditPopup() {
    document.getElementById('edit_popup').classList.remove('active');
    document.body.style.overflow = '';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeEditPopup();
    }
});