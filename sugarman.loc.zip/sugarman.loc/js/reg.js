document.addEventListener('DOMContentLoaded', function () {
        const phoneInput = document.querySelector('input[name="user_number"]');

        phoneInput.addEventListener('input', function (e) {
            let value = e.target.value.replace(/\D/g, '');

            if (value.length === 0) {
                e.target.value = '';
                return;
            }

            if (value.startsWith('7') || value.startsWith('8')) {
                value = value.slice(1); // Убираем 7/8
            }

            if (value.length > 10) {
                value = value.slice(0, 10);
            }

            let formattedValue = '+7 (';
            if (value.length >= 1) formattedValue += value.slice(0, 3);
            if (value.length >= 3) formattedValue += ') ';
            if (value.length >= 4) formattedValue += value.slice(3, 6);
            if (value.length >= 6) formattedValue += '-';
            if (value.length >= 7) formattedValue += value.slice(6, 8);
            if (value.length >= 8) formattedValue += '-';
            if (value.length >= 9) formattedValue += value.slice(8, 10);

            e.target.value = formattedValue;
        });

        const form = document.querySelector('form');
        form.addEventListener('submit', function (e) {
            let phoneField = document.querySelector('input[name="user_number"]');
            let cleanNumber = phoneField.value.replace(/\D/g, '');
            if (cleanNumber.startsWith('7') || cleanNumber.startsWith('8')) {
                cleanNumber = cleanNumber.slice(1);
            }
            phoneField.value = cleanNumber;
        });
    });