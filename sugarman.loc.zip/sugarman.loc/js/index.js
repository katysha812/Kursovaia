document.addEventListener('DOMContentLoaded', function () {
    const openPopUp = document.getElementById('open_pop_up');
    const openPopUpPromo = document.getElementById('open_pop_up_promo');
    const popUp = document.getElementById('pop_up');
    const closePopUp = document.getElementById('close_pop_up');

    function openPopup(e) {
        e.preventDefault();
        popUp.classList.add('active');
    }

    if (openPopUp) {
        openPopUp.addEventListener('click', openPopup);
    }

    if (openPopUpPromo) {
        openPopUpPromo.addEventListener('click', openPopup);
    }

    if (closePopUp) {
        closePopUp.addEventListener('click', function () {
            popUp.classList.remove('active');
        });
    }
});

    document.addEventListener('DOMContentLoaded', function () {
        const phoneInput = document.querySelector('input[name="телефон"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', function () {
                let value = this.value.replace(/\D/g, '');
                if (value.length > 11) {
                    value = value.slice(0, 11);
                }

                if (value.length > 0) {
                    let formatted = '+7 (';

                    if (value.length > 1) formatted += value.slice(0, 3);
                    else formatted += value.slice(0);

                    formatted += ') ';

                    if (value.length > 3) formatted += value.slice(3, 6);
                    else if (value.length > 3) formatted += value.slice(3);

                    formatted += '-';

                    if (value.length > 6) formatted += value.slice(6, 8);
                    else if (value.length > 6) formatted += value.slice(6);

                    formatted += '-';

                    if (value.length > 8) formatted += value.slice(8, 11);

                    this.value = formatted;
                }
            });
        }
    });

    // Расчёт стоимости на главной
    document.addEventListener('DOMContentLoaded', function () {
        const weightInput = document.querySelector('input[name="вес"]');
        const quantityInput = document.querySelector('input[name="количество"]');
        const cakeSelect = document.getElementById('торт');
        const costInput = document.querySelector('input[name="стоимость"]');

        function calculateCost() {
            const selectedCakePrice = parseFloat(cakeSelect.options[cakeSelect.selectedIndex].getAttribute('data-цена'));
            const weight = parseFloat(weightInput.value);
            const quantity = parseInt(quantityInput.value);

            if (!isNaN(selectedCakePrice) && !isNaN(weight) && !isNaN(quantity)) {
                const totalCost = (selectedCakePrice * weight * quantity).toFixed(2);
                costInput.value = `${totalCost} ₽`;
            } else {
                costInput.value = '0.00 ₽';
            }
        }

        weightInput.addEventListener('input', calculateCost);
        quantityInput.addEventListener('input', calculateCost);
        cakeSelect.addEventListener('change', calculateCost);
        window.addEventListener('load', calculateCost);
    });

document.addEventListener('DOMContentLoaded', function() {
    // Массив с путями к изображениям
    const images = [
        'assets/images/BigPicCake1.svg',
        'assets/images/BigPicCake2.svg',
        'assets/images/BigPicCake3.svg',
        'assets/images/BigPicCake4.svg',
        'assets/images/BigPicCake5.svg',
        'assets/images/BigPicCake6.svg',
        'assets/images/BigPicCake7.svg'
    ];

    // Получаем элемент img
    const heroImage = document.getElementById('hero-image');

    // Функция для обновления изображения
    let currentIndex = 0;
    function updateImage() {
        // Сначала делаем изображение прозрачным
        heroImage.style.opacity = 0;

        // Устанавливаем новый путь к изображению
        setTimeout(() => {
            heroImage.src = images[currentIndex];
            heroImage.style.opacity = 1; // Включаем прозрачность после изменения src
        }, 500);

        // Переходим к следующему индексу
        currentIndex = (currentIndex + 1) % images.length;
    }

    // Запускаем первое изображение сразу при загрузке страницы
    updateImage();

    // Автоматическая смена изображений каждые 5 секунд
    setInterval(updateImage, 5000); // 5000 мс = 5 секунд
});