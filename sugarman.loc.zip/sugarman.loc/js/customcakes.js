function toggleAdminForm() {
    const action = document.getElementById('actionSelect').value;
    
    document.getElementById('addForm').style.display = 'none';
    document.getElementById('updateForm').style.display = 'none';
    document.getElementById('deleteForm').style.display = 'none';
    

    if (action === 'add_cake') {
        document.getElementById('addForm').style.display = 'block';
    } else if (action === 'update_cake') {
        document.getElementById('updateForm').style.display = 'block';
    } else if (action === 'delete_cake') {
        document.getElementById('deleteForm').style.display = 'block';
    }
}