function openEditPopup(id, имя, фамилия, никнейм, телефон, почта, дата_рождения, id_адреса, id_роли) {
    console.log("Открытие попапа для пользователя:", id);
    
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_имя').value = имя;
    document.getElementById('edit_фамилия').value = фамилия;
    document.getElementById('edit_никнейм').value = никнейм;
    document.getElementById('edit_телефон').value = formatPhoneForInput(телефон);
    document.getElementById('edit_почта').value = почта;
    document.getElementById('edit_дата_рождения').value = дата_рождения;
    document.getElementById('edit_адрес_доставки').value = id_адреса || '';
    document.getElementById('edit_id_роли').value = id_роли;
    
    const popup = document.getElementById('edit_user_popup');
    popup.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeEditPopup() {
    const popup = document.getElementById('edit_user_popup');
    popup.classList.remove('active');
    document.body.style.overflow = '';
}

function confirmDelete(userId) {
    if (confirm('Вы уверены, что хотите удалить этого пользователя?')) {
        document.getElementById('delete_user_id').value = userId;
        document.getElementById('delete_form').submit();
    }
}

function formatPhoneForInput(phone) {
    phone = phone.replace(/\D/g, '');
    if (phone.length === 11) {
        return `+${phone[0]}(${phone.substring(1,4)})${phone.substring(4,7)}-${phone.substring(7,9)}-${phone.substring(9,11)}`;
    }
    return phone;
}

document.addEventListener('DOMContentLoaded', function() {
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    
    phoneInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            let formatted = '';
            
            if (value.length > 0) {
                formatted = '+' + value[0];
            }
            if (value.length > 1) {
                formatted += '(' + value.substring(1, 4);
            }
            if (value.length > 4) {
                formatted += ')' + value.substring(4, 7);
            }
            if (value.length > 7) {
                formatted += '-' + value.substring(7, 9);
            }
            if (value.length > 9) {
                formatted += '-' + value.substring(9, 11);
            }
            
            e.target.value = formatted;
        });
    });
    
    document.addEventListener('click', function(e) {
        const popup = document.getElementById('edit_user_popup');
        if (popup.classList.contains('active') && e.target === popup) {
            closeEditPopup();
        }
    });
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeEditPopup();
        }
    });
});