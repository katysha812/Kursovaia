<?php
session_start();
// Исправление: Корректное подключение файлов
require_once $_SERVER['DOCUMENT_ROOT'] . '/lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    header('Location: Login.php');
    exit;
}

// Получаем данные пользователя
$userId = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT id_роли FROM пользователи WHERE id = ?");
$stmt->execute([$userId]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$userData) {
    die("Пользователь не найден");
}

$id_роли = $userData['id_роли'];

// Обработка обновления заявки
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_order') {
    $order_id = intval($_POST['order_id']);
    $status = intval($_POST['status']);
    
    $weight = isset($_POST['weight']) ? floatval($_POST['weight']) : null;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : null;
    $address = isset($_POST['address']) ? intval($_POST['address']) : null;
    $comment = filter_var($_POST['comment'] ?? '', FILTER_SANITIZE_SPECIAL_CHARS);
    
    try {
        // Обновление для менеджера
        if ($id_роли == 2) {
            $stmt = $pdo->prepare("UPDATE заявки SET id_статус_заявки = ? WHERE id = ?");
            $stmt->execute([$status, $order_id]);
        }
        // Обновление для администратора
        elseif ($id_роли == 3) {
            $stmt = $pdo->prepare("UPDATE заявки SET 
                id_статус_заявки = ?, 
                вес = ?, 
                количество = ?, 
                id_адрес_доставки = ?, 
                примечания = ?
                WHERE id = ?");
            $stmt->execute([$status, $weight, $quantity, $address, $comment, $order_id]);
        }
        
        $_SESSION['success'] = 'Заявка успешно обновлена';
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } catch (PDOException $e) {
        $_SESSION['error'] = "Ошибка при обновлении заявки: " . $e->getMessage();
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
}

// Обработка удаления заявки
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_order') {
    $order_id = intval($_POST['order_id']);
    
    try {
        $stmt = $pdo->prepare("DELETE FROM заявки WHERE id = ?");
        $stmt->execute([$order_id]);
        $_SESSION['success'] = 'Заявка успешно удалена';
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } catch (PDOException $e) {
        $_SESSION['error'] = "Ошибка при удалении заявки: " . $e->getMessage();
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
}

// Получаем список всех заявок
try {
    if ($id_роли == 1) {
        // Обычный пользователь видит только свои заявки
        $sql = "
            SELECT 
                з.id,
                з.id_статус_заявки,
                з.id_начинки,
                з.id_адрес_доставки,
                п.имя,
                п.фамилия,
                п.никнейм,
                н.название AS начинка,
                т.название AS торт,
                т.фото AS фото,
                з.вес,
                з.количество,
                з.дата_мероприятия,
                з.стоимость,
                з.примечания,
                г.название AS город,
                у.название AS улица,
                a.номер_дома,
                s.название AS статус
            FROM заявки з
            LEFT JOIN пользователи п ON з.id_пользователя = п.id
            LEFT JOIN начинки н ON з.id_начинки = н.id
            LEFT JOIN торты т ON з.id_торта = т.id
            LEFT JOIN адреса a ON з.id_адрес_доставки = a.id
            LEFT JOIN улицы у ON a.id_улицы = у.id
            LEFT JOIN города г ON у.id_города = г.id
            LEFT JOIN статус_заявки s ON з.id_статус_заявки = s.id
            WHERE з.id_пользователя = ?
            ORDER BY з.дата_мероприятия ASC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId]);
    } else {
        // Админ и менеджер видят все заявки
        $sql = "
            SELECT 
                з.id,
                з.id_статус_заявки,
                з.id_начинки,
                з.id_адрес_доставки,
                п.имя,
                п.фамилия,
                п.никнейм,
                н.название AS начинка,
                т.название AS торт,
                т.фото AS фото,
                з.вес,
                з.количество,
                з.дата_мероприятия,
                з.стоимость,
                з.примечания,
                г.название AS город,
                у.название AS улица,
                a.номер_дома,
                s.название AS статус
            FROM заявки з
            LEFT JOIN пользователи п ON з.id_пользователя = п.id
            LEFT JOIN начинки н ON з.id_начинки = н.id
            LEFT JOIN торты т ON з.id_торта = т.id
            LEFT JOIN адреса a ON з.id_адрес_доставки = a.id
            LEFT JOIN улицы у ON a.id_улицы = у.id
            LEFT JOIN города г ON у.id_города = г.id
            LEFT JOIN статус_заявки s ON з.id_статус_заявки = s.id
            ORDER BY з.дата_мероприятия ASC
        ";
        $stmt = $pdo->query($sql);
    }

    $заявки = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении заявок: " . $e->getMessage());
}

// Получаем список статусов для формы
$stmtStatuses = $pdo->query("SELECT id, название FROM статус_заявки");
$statuses = $stmtStatuses->fetchAll(PDO::FETCH_ASSOC);

// Получаем список адресов для формы (для админа и менеджера)
if ($id_роли == 2 || $id_роли == 3) {
    $stmtAddresses = $pdo->query("
        SELECT a.id, г.название AS город, у.название AS улица, a.номер_дома
        FROM адреса a 
        JOIN улицы у ON a.id_улицы = у.id 
        JOIN города г ON у.id_города = г.id
    ");
    $addresses = $stmtAddresses->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Все заявки</title>
    <link rel="stylesheet" href="css/main.css" type="text/css"/>
    <link rel="stylesheet" href="css/statistic.css" type="text/css"/>
    <link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <link rel="stylesheet" href="css/footer.css" type="text/css"/>
    <link rel="stylesheet" href="css/popup.css" type="text/css"/>
    <link rel="stylesheet" href="css/orders.css" type="text/css"/>
</head>
<body>

<div class="wrapper">
    <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/blocks/header.php'; ?>
    
    <!-- Вывод сообщений об ошибках/успехе -->
    <?php if (isset($_SESSION['error'])): ?>
        <div class="error-message"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="success-message"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <!-- Контейнер с заявками -->
    <div class="statistic-container">
        <h1>Заявки на торты</h1>

        <div class="cards-statistics">
            <?php if (empty($заявки)): ?>
                <p>Нет заявок.</p>
            <?php else: ?>
                <?php foreach ($заявки as $заявка): ?>
                    <div class="card-statistic">
                        <div class="pic-user">
                            <img src="<?= !empty($заявка['фото']) ? htmlspecialchars($заявка['фото']) : 'assets/images/PicStatistic.svg' ?>" alt="<?= htmlspecialchars($заявка['торт'] ?? 'Торт') ?>">
                            <h3><?= htmlspecialchars($заявка['имя'] ?? '') ?> <?= htmlspecialchars($заявка['фамилия'] ?? '') ?></h3>
                            <p>@<?= htmlspecialchars($заявка['никнейм'] ?? 'пользователь') ?></p>
                        </div>
                        <div class="text-statistic">
                            <h2>Начинка: <?= htmlspecialchars($заявка['начинка'] ?? 'Не указана') ?></h2>
                            <h2>Торт: <?= htmlspecialchars($заявка['торт'] ?? 'Не указан') ?></h2>
                            <p><strong>Дата:</strong> <?= htmlspecialchars($заявка['дата_мероприятия'] ?? '—') ?></p>
                            <p><strong>Вес:</strong> <?= number_format($заявка['вес'], 2, '.', '') ?> кг</p>
                            <p><strong>Количество:</strong> <?= htmlspecialchars($заявка['количество'] ?? 0) ?></p>
                            <p><strong>Стоимость:</strong> <?= number_format($заявка['стоимость'] ?? 0, 2, '.', '') ?> ₽</p>
                            <p><strong>Адрес доставки:</strong> 
                                <?= htmlspecialchars("{$заявка['город']}, ул. {$заявка['улица']}, д. {$заявка['номер_дома']}") ?>
                            </p>
                            <p><strong>Примечание:</strong> <?= htmlspecialchars($заявка['примечания'] ?? '(нет)') ?></p>
                            <p><strong>Статус заявки:</strong> <b><?= htmlspecialchars($заявка['статус'] ?? 'Неизвестный статус') ?></b></p>

                            <!-- Кнопки только для админа и менеджера -->
                            <?php if ($id_роли == 2 || $id_роли == 3): ?>
                                <div class="user-actions">
                                    <button class="btn-edit" 
                                            onclick="openEditPopup(<?= htmlspecialchars(json_encode([
                                                'id' => $заявка['id'],
                                                'id_статус_заявки' => $заявка['id_статус_заявки'],
                                                'вес' => $заявка['вес'],
                                                'количество' => $заявка['количество'],
                                                'id_адрес_доставки' => $заявка['id_адрес_доставки'],
                                                'примечания' => $заявка['примечания']
                                            ]), ENT_QUOTES, 'UTF-8') ?>)">
                                        Редактировать
                                    </button>

                                    <!-- Кнопка удаления (только для админа) -->
                                    <?php if ($id_роли == 3): ?>
                                        <button class="btn-delete" onclick="confirmDelete(<?= $заявка['id'] ?>)">Удалить</button>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/blocks/footer.php'; ?>

<!-- Попап редактирования заявки -->
<div class="pop_up" id="edit_order_popup">
    <div class="pop_up_container">
        <div class="pop_up_body">
            <div class="pop_up_close" onclick="closeEditPopup()">×</div>
            <h2>Редактировать заявку</h2>
            <form id="edit_order_form" method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <input type="hidden" name="action" value="update_order">
                <input type="hidden" name="order_id" id="popup_order_id">

                <!-- Статус заявки -->
                <div class="form-group">
                    <label for="popup_status">Статус:</label>
                    <select name="status" id="popup_status" required>
                        <?php foreach ($statuses as $status): ?>
                            <option value="<?= $status['id'] ?>"><?= htmlspecialchars($status['название']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Только администратор (роль 3) видит остальные поля -->
                <?php if ($id_роли == 3): ?>
                    <div class="form-group">
                        <label for="popup_weight">Вес:</label>
                        <input type="number" step="0.1" min="0.3" max="25" name="weight" id="popup_weight" placeholder="Вес (кг)" required>
                    </div>

                    <div class="form-group">
                        <label for="popup_quantity">Количество:</label>
                        <input type="number" name="quantity" id="popup_quantity" min="1" placeholder="Количество" required>
                    </div>

                    <div class="form-group">
                        <label for="popup_address">Адрес доставки:</label>
                        <select name="address" id="popup_address" required>
                            <option value="">Выберите адрес</option>
                            <?php foreach ($addresses as $address): ?>
                                <option value="<?= $address['id'] ?>">
                                    <?= htmlspecialchars("{$address['город']}, ул. {$address['улица']}, д. {$address['номер_дома']}") ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="popup_comment">Примечание:</label>
                        <input type="text" name="comment" id="popup_comment" placeholder="Дополнительное примечание">
                    </div>
                <?php endif; ?>

                <button type="submit" class="btn-save">Сохранить изменения</button>
            </form>
        </div>
    </div>
</div>

<!-- Форма для удаления заявки -->
<form id="delete_form" method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" style="display: none;">
    <input type="hidden" name="action" value="delete_order">
    <input type="hidden" name="order_id" id="delete_order_id">
</form>

<script>
    function openEditPopup(data) {
        // Заполняем скрытое поле ID
        document.getElementById('popup_order_id').value = data.id;
        
        // Устанавливаем статус
        document.getElementById('popup_status').value = data.id_статус_заявки;

        // Если админ - заполняем дополнительные поля
        <?php if ($id_роли == 3): ?>
            document.getElementById('popup_weight').value = data.вес;
            document.getElementById('popup_quantity').value = data.количество;
            document.getElementById('popup_address').value = data.id_адрес_доставки;
            document.getElementById('popup_comment').value = data.примечания || '';
        <?php endif; ?>

        // Открываем попап
        const popup = document.getElementById('edit_order_popup');
        popup.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeEditPopup() {
        const popup = document.getElementById('edit_order_popup');
        popup.classList.remove('active');
        document.body.style.overflow = '';
    }

    function confirmDelete(orderId) {
        if (confirm('Вы уверены, что хотите удалить эту заявку?')) {
            document.getElementById('delete_order_id').value = orderId;
            document.getElementById('delete_form').submit();
        }
    }
    
    // Закрытие попапа при клике вне его
    document.addEventListener('click', function(e) {
        const popup = document.getElementById('edit_order_popup');
        if (popup.classList.contains('active') && e.target === popup) {
            closeEditPopup();
        }
    });
    
    // Закрытие попапа при нажатии ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeEditPopup();
        }
    });
</script>
</body>
</html>