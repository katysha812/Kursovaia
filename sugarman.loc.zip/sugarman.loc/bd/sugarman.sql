-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: mysql-8.0
-- Время создания: Июн 16 2025 г., 19:53
-- Версия сервера: 8.0.41
-- Версия PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `sugarman`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Статус_заявки`
--

CREATE TABLE `Статус_заявки` (
  `id` tinyint UNSIGNED NOT NULL,
  `Название` varchar(150) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `Статус_заявки`
--

INSERT INTO `Статус_заявки` (`id`, `Название`) VALUES
(1, 'Создана'),
(2, 'В работе'),
(3, 'В службе доставки'),
(4, 'Завершена');

-- --------------------------------------------------------

--
-- Структура таблицы `пользователи`
--

CREATE TABLE `пользователи` (
  `id` int UNSIGNED NOT NULL,
  `id_роли` int UNSIGNED NOT NULL,
  `имя` varchar(100) NOT NULL,
  `фамилия` varchar(100) NOT NULL,
  `никнейм` varchar(15) NOT NULL,
  `id_адреса` int UNSIGNED NOT NULL,
  `телефон` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `почта` varchar(100) NOT NULL,
  `пароль` varchar(100) NOT NULL,
  `дата_рождения` date NOT NULL DEFAULT '9999-12-31'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `пользователи`
--

INSERT INTO `пользователи` (`id`, `id_роли`, `имя`, `фамилия`, `никнейм`, `id_адреса`, `телефон`, `почта`, `пароль`, `дата_рождения`) VALUES
(1, 3, 'Екатерина', 'Постоева', 'sashokohh', 1, '79832750817', 'istp11postoevakatya@gmail.com', '$2y$10$FLgYUqEnFPGMc7Mb1qWLBuFod6.Cf5u.Z.fY/uMPp.URViD6SySjq', '2007-05-28'),
(2, 1, 'Александра', 'Попкорнова', 'popkor', 2, '9936669806', 'popkorn4ik@mail.ru', '74d4e43a96da700355407176dea1240b', '2006-06-09'),
(4, 1, 'Покупатель', 'Покупателев', 'pokup', 3, '9000990989', 'lololoolo@gmail.com', '50b3fa064f9ea86dd10f850e5bfbbecb', '2000-06-05'),
(5, 2, 'Анна', 'Сладкоежкина', 'sladkaya', 3, '8834569823', 'sladkoezkina@gmail.com', '50b3fa064f9ea86dd10f850e5bfbbecb', '2000-04-04'),
(6, 1, 'Фанаттья', 'Пловкина', 'fanat0plova', 4, '9999999999', 'hello@gmail.com', '50b3fa064f9ea86dd10f850e5bfbbecb', '2025-06-11'),
(7, 1, 'Надежда', 'Гвинова', 'Gnuawyy', 14, '79832887832', 'gnuwyy@gmail.com', '50b3fa064f9ea86dd10f850e5bfbbecb', '2000-12-31'),
(16, 2, 'катюха', 'менеджер', 'sashokohh1', 28, '79000990998', 'sashokohhchik@gmail.com', '$2y$10$XK1Z/.JCOCsVg591vqWKku5YQ5GCo2wO1KRX2.6dHF4M127YBjk0q', '2025-05-28'),
(17, 2, 'катюха', 'менеджер', 'sashokohh2', 27, '79000990998', 'sashokohhchik2@gmail.com', '$2y$10$NblIunhBRtp8B2Q4azGNievfV0I8oMoQq0UbMfcS7R/T3GSWUBTI2', '2025-06-06'),
(18, 2, 'катюха', 'менеджер', 'sashokohh3', 21, '79000990998', 'sashokohhchik@gmail.com', '$2y$10$epMHUisGvScyyqj66oOD6.NNpueiERb89yRmzHDe.bqKr.DmU92bS', '2025-06-15'),
(19, 1, 'Имя2', 'Фамилия', 'nickname', 11, '79999999999', 'mailmail@mail.ru', '$2y$10$iiV/ltiHMUW4UcgYC4CeJ.QwztzLVZ/gReSaEF//8DezVrS3H0/Cu', '2025-06-10'),
(22, 1, 'Имя', 'Фамилия', 'nickname', 11, '9999999999', 'mailmail@mail.ru', '50b3fa064f9ea86dd10f850e5bfbbecb', '2025-06-10');

-- --------------------------------------------------------

--
-- Структура таблицы `адреса`
--

CREATE TABLE `адреса` (
  `id` int UNSIGNED NOT NULL,
  `id_улицы` int UNSIGNED NOT NULL,
  `Номер_дома` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `адреса`
--

INSERT INTO `адреса` (`id`, `id_улицы`, `Номер_дома`) VALUES
(1, 1, '62'),
(2, 2, '44'),
(3, 3, '33'),
(4, 4, '69'),
(5, 7, '7А'),
(6, 5, '5'),
(7, 5, '3А'),
(8, 7, '7'),
(9, 7, '56'),
(10, 6, '48'),
(11, 6, '48А'),
(12, 12, '12'),
(13, 12, '55'),
(14, 13, '13'),
(15, 13, '79'),
(16, 14, '14'),
(17, 14, '41'),
(18, 17, '28'),
(19, 17, '17'),
(20, 19, '19'),
(21, 19, '69'),
(22, 20, '20'),
(23, 20, '49А'),
(24, 1, '52'),
(25, 4, '4'),
(26, 4, '24'),
(27, 3, '3'),
(28, 3, '33'),
(29, 8, '8'),
(30, 8, '99'),
(31, 10, '10'),
(32, 10, '55'),
(33, 9, '9'),
(34, 9, '27'),
(35, 16, '16'),
(36, 16, '61'),
(37, 15, '15'),
(38, 15, '46'),
(39, 2, '24'),
(40, 2, '2'),
(41, 2, '3'),
(42, 2, '4'),
(43, 11, '1'),
(44, 11, '2'),
(45, 11, '3'),
(46, 11, '4'),
(47, 11, '5'),
(48, 11, '6'),
(49, 18, '20'),
(50, 18, '19'),
(51, 18, '18'),
(52, 24, '21А'),
(53, 24, '57'),
(54, 24, '24'),
(55, 22, '22'),
(56, 22, '21А'),
(57, 22, '20В'),
(58, 23, '23'),
(59, 23, '41'),
(60, 23, '25'),
(61, 23, '91'),
(62, 21, '4'),
(63, 21, '6'),
(64, 19, '29'),
(65, 1, '1'),
(126, 21, '5');

-- --------------------------------------------------------

--
-- Структура таблицы `города`
--

CREATE TABLE `города` (
  `id` int UNSIGNED NOT NULL,
  `Название` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `города`
--

INSERT INTO `города` (`id`, `Название`) VALUES
(1, 'Абакан');

-- --------------------------------------------------------

--
-- Структура таблицы `заявки`
--

CREATE TABLE `заявки` (
  `id` int UNSIGNED NOT NULL,
  `id_пользователя` int UNSIGNED NOT NULL,
  `id_торта` int UNSIGNED NOT NULL,
  `id_начинки` int UNSIGNED NOT NULL,
  `вес` double NOT NULL,
  `количество` int NOT NULL,
  `стоимость` double NOT NULL,
  `примечания` text,
  `дата_заявки` date NOT NULL DEFAULT '9999-12-31',
  `дата_мероприятия` date NOT NULL DEFAULT '9999-12-31',
  `id_адрес_доставки` int UNSIGNED NOT NULL,
  `id_статус_заявки` tinyint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `заявки`
--

INSERT INTO `заявки` (`id`, `id_пользователя`, `id_торта`, `id_начинки`, `вес`, `количество`, `стоимость`, `примечания`, `дата_заявки`, `дата_мероприятия`, `id_адрес_доставки`, `id_статус_заявки`) VALUES
(1, 5, 5, 4, 1, 3, 6642, 'Без орехов и шоколада', '2025-06-11', '2025-06-28', 2, 2),
(2, 6, 4, 7, 2, 2, 299000, 'пожалуйста нарисуйте котика на упаковке тортиков в честь дня рождения', '2025-06-11', '2025-06-11', 4, 2),
(3, 6, 9, 5, 1, 3, 5985, 'Больше крема, меньше бисквита.', '2025-06-11', '2025-06-21', 2, 4),
(4, 6, 7, 5, 1, 6, 14940, 'Клубнику маленького размера', '2025-06-11', '2025-06-14', 1, 2),
(5, 1, 4, 9, 1.5, 1, 4036.5, 'К чаю для администратора)', '2025-06-12', '2025-06-28', 1, 1),
(6, 1, 12, 1, 1.5, 1, 5235, 'В подарок боссу!', '2025-06-12', '2025-06-19', 1, 1),
(7, 7, 3, 8, 1, 2, 4122, 'Сделайте торт в голубых тонах', '2025-06-12', '2025-06-13', 4, 2),
(8, 7, 22, 2, 1, 2, 7380, 'Добавьте кокосовую стружку сверху', '2025-06-12', '2025-06-14', 45, 2),
(9, 19, 7, 6, 1, 1, 2241, 'Примечание', '2025-06-16', '2025-06-21', 2, 1),
(10, 19, 2, 3, 1, 1, 3000, 'примечание', '2025-06-16', '2025-06-20', 28, 1),
(11, 19, 5, 1, 1.5, 2, 11070, 'Primechanie', '2025-06-16', '2025-06-20', 40, 1),
(12, 19, 9, 7, 0.7, 1, 2793, 'Примечание2', '2025-06-16', '2025-06-19', 65, 1),
(13, 19, 5, 1, 5, 2, 36900, 'Primechanie', '2025-06-16', '2025-06-20', 40, 1),
(14, 19, 9, 7, 7, 1, 27930, 'Примечание2', '2025-06-16', '2025-06-19', 65, 1),
(15, 1, 3, 3, 1, 1, 2290, 'Больше крема, меньше бисквита.', '2025-06-16', '2025-06-27', 41, 1),
(16, 1, 3, 3, 1, 1, 2290, 'Больше крема, меньше бисквита.', '2025-06-16', '2025-06-27', 41, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `начинки`
--

CREATE TABLE `начинки` (
  `id` int UNSIGNED NOT NULL,
  `фото` varchar(500) NOT NULL,
  `название` varchar(200) NOT NULL,
  `описание` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `начинки`
--

INSERT INTO `начинки` (`id`, `фото`, `название`, `описание`) VALUES
(1, 'assets/images/topping1.svg', 'Розовая фантазия', 'Нежный розовый бисквит с прослойкой из заварного крема.'),
(2, 'assets/images/topping2.svg', 'Лимонный восторг', 'Классический бисквит с легким сливочным кремом и кисло-сладкой лимонной прослойкой.'),
(3, 'assets/images/topping3.svg', 'Фисташка-малина', 'Фисташковый бисквит с прослойкой из малинового конфи и сливочного крема'),
(4, 'assets/images/topping4.svg', 'Сладкое мгновенье', 'Ванильный бисквит с вишневым джемом и сладким заварным кремом'),
(5, 'assets/images/topping5.svg', 'Красный бархат', 'Популярный американский торт с рассыпчатым бисквитом и нежным кремом на основе сыра «Филадельфия».'),
(6, 'assets/images/topping6.svg', 'Шоколадный каприз', 'Шоколадный бисквит с нежным суфле и клубничным желе'),
(7, 'assets/images/topping7.svg', 'Ореховая кома', 'Тёмный шоколадный торт с многослойным бисквитом, наполненный нежной карамелью и арахисом.'),
(8, 'assets/images/topping8.svg', 'Черничный бриз', 'Воздушный черничный бисквит с сливочным кремом и молочной пропиткой.'),
(9, 'assets/images/topping9.svg', 'Шоколадная эйфория', 'Нежный торт с шоколадным бисквитом, наполненный классическим шоколадным кремом.');

-- --------------------------------------------------------

--
-- Структура таблицы `отзывы`
--

CREATE TABLE `отзывы` (
  `id` int UNSIGNED NOT NULL,
  `id_пользователя` int UNSIGNED NOT NULL,
  `Дата` datetime NOT NULL DEFAULT '9999-12-31 23:59:59',
  `Фото` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Заголовок` varchar(150) NOT NULL,
  `Содержание` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `отзывы`
--

INSERT INTO `отзывы` (`id`, `id_пользователя`, `Дата`, `Фото`, `Заголовок`, `Содержание`) VALUES
(1, 5, '2025-06-12 10:06:59', 'assets/images/Statistic1.svg', 'Самый вкусный торт!', 'Заказывала торт красный бархат и выбрала свой дизайн, очень вкусно и красиво спасибо вам большое!'),
(2, 6, '2025-06-09 03:09:03', 'assets/images/Statistic3.svg', 'Торт дочке', 'Заказывала торт на день рождения, очень вкусно, дочке понравилось'),
(3, 4, '2025-05-28 21:29:19', 'assets/images/Statistic2.svg', 'Торт на семейный праздник', 'Люблю эту кондитерскую за мастерский подход к любому десерту! Заказывала торт на семейный праздник, очень понравился!');

-- --------------------------------------------------------

--
-- Структура таблицы `роли`
--

CREATE TABLE `роли` (
  `id` int UNSIGNED NOT NULL,
  `Название` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `роли`
--

INSERT INTO `роли` (`id`, `Название`) VALUES
(3, 'Администратор'),
(4, 'Гость'),
(2, 'Менеджер'),
(1, 'Пользователь');

-- --------------------------------------------------------

--
-- Структура таблицы `улицы`
--

CREATE TABLE `улицы` (
  `id` int UNSIGNED NOT NULL,
  `id_города` int UNSIGNED NOT NULL,
  `Название` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `улицы`
--

INSERT INTO `улицы` (`id`, `id_города`, `Название`) VALUES
(1, 1, 'Проспект Ленина'),
(2, 1, 'Лермонтова'),
(3, 1, 'Пушкина'),
(4, 1, 'Проселкина'),
(5, 1, 'Авиаторов'),
(6, 1, 'Аскизская'),
(7, 1, 'Арбан'),
(8, 1, 'Вокзальная'),
(9, 1, 'Гоголя'),
(10, 1, 'Гагарина'),
(11, 1, 'Лесная'),
(12, 1, 'Карла Маркса'),
(13, 1, 'Кати Перекрещенко'),
(14, 1, 'Катанова'),
(15, 1, 'Итыгина'),
(16, 1, 'Доможакова'),
(17, 1, 'Кутузова'),
(18, 1, 'Ломоносова'),
(19, 1, 'Мира'),
(20, 1, 'Некрасова'),
(21, 1, 'Родниковая'),
(22, 1, 'Чертыгашева'),
(23, 1, 'Чехова'),
(24, 1, 'Тараса Шевченко');

-- --------------------------------------------------------

--
-- Структура таблицы `торты`
--

CREATE TABLE `торты` (
  `id` int UNSIGNED NOT NULL,
  `фото` varchar(500) NOT NULL,
  `название` varchar(200) NOT NULL,
  `описание` varchar(500) NOT NULL,
  `цена_кг` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `торты`
--

INSERT INTO `торты` (`id`, `фото`, `название`, `описание`, `цена_кг`) VALUES
(1, 'assets/images/cake1.svg', 'Торт ламбет с вишенками', 'Торт ламбет украшенный ягодами вишни', 2890),
(2, 'assets/images/cake2.svg', 'Торт ламбет с бантиками', 'Торт на заказ с узорами из крема и декором в виде бантиков', 3000),
(3, 'assets/images/cake3.svg', 'Happy 18!', 'Торт ламбет на заказ с бантиками и надписью', 2290),
(4, 'assets/images/cake4.svg', 'cherry\'s sweet 20th', 'Торт с надписью, вишенками и украшениями', 2990),
(5, 'assets/images/cake5.svg', 'Вальс роз', 'Основной декор торта - цветы из крема', 3690),
(6, 'assets/images/cake6.svg', 'Нежная принцесса', 'Торт с бантиками из крема', 3800),
(7, 'assets/images/cake7.svg', 'Клубника со сливками', 'Основной декор - свежая клубника и бантики', 2490),
(8, 'assets/images/cake8.svg', 'happy birthday', 'украшения из ягод и яркого крема', 3690),
(9, 'assets/images/cake9.svg', 'forever young', 'Торт-ламбет с бусинками и ягодами вишни', 3990),
(10, 'assets/images/cake10.svg', 'Королевский сад XVII', 'Торт украшен цветами из крема и бусинами', 3990),
(11, 'assets/images/cake11.svg', 'Princess dress', 'Торт в форме сердца с милыми бантиками', 3690),
(12, 'assets/images/cake12.svg', 'Strawberry shortcake', 'Клубничный торт с узорами из крема', 3490),
(13, 'assets/images/cake13.svg', 'Real or fake?', 'Торт в пастельных тонах с вишенками', 2990),
(14, 'assets/images/cake14.svg', 'Gemini', 'Торт с выкладными буквами и декором', 3990),
(15, 'assets/images/cake15.svg', 'Roses and tears', 'Детальный торт с большой надписью', 3690),
(16, 'assets/images/cake16.svg', 'Клубничный принц', 'Торт с большими ягодами клубники', 2690),
(17, 'assets/images/cake17.svg', 'EIGHTEEN', 'Детализированный торт с бантиками', 4590),
(18, 'assets/images/cake18.svg', 'Damaged', 'Торт с контрастом оттенков крема и вишенками', 3690),
(19, 'assets/images/cake19.svg', 'Заколки :3', 'Бантики на вишенках и ажурные узоры', 4050),
(20, 'assets/images/cake20.svg', 'cherry BOOM!', 'Торт с разной техникой нанесения крема', 2580),
(21, 'assets/images/cake21.svg', 'hello kitty-!', 'Торт с узором в готическом стиле', 3790),
(22, 'assets/images/cake22.svg', 'Хлорка и ваниль', 'Декор с цветами в темных тонах', 3690),
(23, 'assets/images/cake23.svg', 'sixteen', 'Торт с множеством украшений', 5900),
(24, 'assets/images/cake24.svg', 'Brain and heart', 'Торт с необычными узорами и декором', 4500),
(25, 'assets/images/cakeex.svg', 'Свой вариант', 'С вами свяжется менеджер и уточнит все детали  (Цена зависит от сложности дизайна)', 9999),
(30, 'uploads/cakes/684e979c9153d.svg', '11111', 'аууууууууу', 3333);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Статус_заявки`
--
ALTER TABLE `Статус_заявки`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `пользователи`
--
ALTER TABLE `пользователи`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `никнейм` (`никнейм`,`телефон`,`почта`),
  ADD KEY `id_роли` (`id_роли`),
  ADD KEY `id_адреса` (`id_адреса`);

--
-- Индексы таблицы `адреса`
--
ALTER TABLE `адреса`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_улицы` (`id_улицы`);

--
-- Индексы таблицы `города`
--
ALTER TABLE `города`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Название` (`Название`);

--
-- Индексы таблицы `заявки`
--
ALTER TABLE `заявки`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_пользователя` (`id_пользователя`),
  ADD KEY `id_торта` (`id_торта`),
  ADD KEY `id_начинки` (`id_начинки`),
  ADD KEY `id_адрес_доставки` (`id_адрес_доставки`),
  ADD KEY `id_статус_заявки` (`id_статус_заявки`),
  ADD KEY `id_статус_заявки_2` (`id_статус_заявки`);

--
-- Индексы таблицы `начинки`
--
ALTER TABLE `начинки`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `отзывы`
--
ALTER TABLE `отзывы`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_пользователя` (`id_пользователя`);

--
-- Индексы таблицы `роли`
--
ALTER TABLE `роли`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Название` (`Название`);

--
-- Индексы таблицы `улицы`
--
ALTER TABLE `улицы`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_города` (`id_города`);

--
-- Индексы таблицы `торты`
--
ALTER TABLE `торты`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Статус_заявки`
--
ALTER TABLE `Статус_заявки`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `пользователи`
--
ALTER TABLE `пользователи`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `адреса`
--
ALTER TABLE `адреса`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT для таблицы `города`
--
ALTER TABLE `города`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `заявки`
--
ALTER TABLE `заявки`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `начинки`
--
ALTER TABLE `начинки`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `отзывы`
--
ALTER TABLE `отзывы`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `роли`
--
ALTER TABLE `роли`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `улицы`
--
ALTER TABLE `улицы`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `торты`
--
ALTER TABLE `торты`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `пользователи`
--
ALTER TABLE `пользователи`
  ADD CONSTRAINT `@v0@u0@r0@o1@n0@u0@i0@g0@y0@l0@r0@o0_ibfk_1` FOREIGN KEY (`id_роли`) REFERENCES `роли` (`id`),
  ADD CONSTRAINT `пользователи_ibfk_1` FOREIGN KEY (`id_адреса`) REFERENCES `адреса` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `адреса`
--
ALTER TABLE `адреса`
  ADD CONSTRAINT `@g0@k0@w0@l0@x0@g0_ibfk_1` FOREIGN KEY (`id_улицы`) REFERENCES `улицы` (`id`);

--
-- Ограничения внешнего ключа таблицы `заявки`
--
ALTER TABLE `заявки`
  ADD CONSTRAINT `заявки_ibfk_1` FOREIGN KEY (`id_пользователя`) REFERENCES `пользователи` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `заявки_ibfk_2` FOREIGN KEY (`id_начинки`) REFERENCES `начинки` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `заявки_ibfk_3` FOREIGN KEY (`id_торта`) REFERENCES `торты` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `заявки_ibfk_4` FOREIGN KEY (`id_адрес_доставки`) REFERENCES `адреса` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `заявки_ibfk_5` FOREIGN KEY (`id_статус_заявки`) REFERENCES `Статус_заявки` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `отзывы`
--
ALTER TABLE `отзывы`
  ADD CONSTRAINT `отзывы_ibfk_1` FOREIGN KEY (`id_пользователя`) REFERENCES `пользователи` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `улицы`
--
ALTER TABLE `улицы`
  ADD CONSTRAINT `улицы_ibfk_1` FOREIGN KEY (`id_города`) REFERENCES `города` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
