<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>О нас</title>
    <Link rel="stylesheet" href="css/main.css" type="text/css"/>
    <Link rel="stylesheet" href="css/aboutus.css" type="text/css"/>
    <Link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <Link rel="stylesheet" href="css/footer.css" type="text/css"/>
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once "blocks/header.php"; ?>
        <!-- О себе -->
        <div class="about-container">
            <h2>О нас</h2>
            <div class="about-info">
                <p><b>Добро пожаловать в нашу кондитерскую, где каждый торт — это произведение искусства! </b> Мы создаем уникальные ламбет-торты, которые не просто украшают праздник, а превращают его в незабываемую сказку. Наши десерты — это гармония изысканного вкуса и безупречного дизайна, где каждый элемент продуман до мелочей.</p>
                <img src="" alt="" id="about-us-image"> 
            </div>
        </div>
            
    </div>

    <div class="wrapper2">
        <!-- Контакты -->
        <?php require_once "blocks/cont.php"; ?>
    </div>

    <?php require_once "blocks/footer.php"; ?>

    <script src="js/aboutus.js"></script>
</body>
</html>