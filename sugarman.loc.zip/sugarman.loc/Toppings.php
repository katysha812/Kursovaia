<?php
session_start();
require_once 'lib/db.php';

$id_роли = null;
if (isset($_SESSION['id'])) {
    $userId = $_SESSION['id'];
    $stmt = $pdo->prepare("SELECT id_роли FROM Пользователи WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $id_роли = $user['id_роли'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_topping'])) {
    if ($id_роли == 2 || $id_роли == 3) {
        $name = trim(filter_var($_POST['name'], FILTER_SANITIZE_SPECIAL_CHARS));
        $description = trim(filter_var($_POST['description'], FILTER_SANITIZE_SPECIAL_CHARS));
        
        $photoPath = '';
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/toppings/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $extension;
            $photoPath = $uploadDir . $filename;
            
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath)) {
                $_SESSION['error'] = 'Ошибка при загрузке изображения';
            }
        }

        try {
            $sql = "INSERT INTO начинки (название, описание, фото) VALUES (?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $description, $photoPath]);
            
            $_SESSION['success'] = '';
            header('Location: toppings.php');
            exit;
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Ошибка при добавлении начинки: ' . $e->getMessage();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_topping'])) {
    if ($id_роли == 3) {
        $id = intval($_POST['id']);
        $name = trim(filter_var($_POST['name'], FILTER_SANITIZE_SPECIAL_CHARS));
        $description = trim(filter_var($_POST['description'], FILTER_SANITIZE_SPECIAL_CHARS));
        
        $stmt = $pdo->prepare("SELECT фото FROM начинки WHERE id = ?");
        $stmt->execute([$id]);
        $currentTopping = $stmt->fetch(PDO::FETCH_ASSOC);
        $photoPath = $currentTopping['фото'];
        
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/toppings/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            if ($photoPath && file_exists($photoPath)) {
                unlink($photoPath);
            }
            
            $extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $extension;
            $photoPath = $uploadDir . $filename;
            
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath)) {
                $_SESSION['error'] = 'Ошибка при загрузке изображения';
            }
        }

        try {
            $sql = "UPDATE начинки SET название = ?, описание = ?, фото = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $description, $photoPath, $id]);
            
            $_SESSION['success'] = '';
            header('Location: toppings.php');
            exit;
        } catch (PDOException $e) {
            $_SESSION['error'] = 'Ошибка при обновлении начинки: ' . $e->getMessage();
        }
    }
}

try {
    $sql = "SELECT id, название, фото, описание FROM начинки";
    $stmt = $pdo->query($sql);
    $начинки = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении начинок: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Начинки</title>
    <link rel="stylesheet" href="css/main.css" type="text/css"/>
    <link rel="stylesheet" href="css/toppings.css" type="text/css"/>
    <link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <link rel="stylesheet" href="css/footer.css" type="text/css"/>
    <link rel="stylesheet" href="css/popup.css" type="text/css"/>
    <link rel="stylesheet" href="css/registration.css" type="text/css"/>
    <link rel="stylesheet" href="css/toppings2.css" type="text/css"/>
</head>
<body>

<div class="wrapper">
    <!-- Шапка сайта -->
    <?php require_once "blocks/header.php"; ?>

    <!-- Сообщения об ошибках/успехе -->
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <!-- Начинки -->
    <div class="container-toppings full">
        <!-- Заголовок и кнопка начинок -->
        <div class="title-toppings">
            <h2>Начинки</h2>
        </div>

        <!-- Обертка для карточек -->
        <div class="cards-toppings">
            <?php foreach ($начинки as $начинка): ?>
                <div class="card-topping">
                    <div class="block">
                        <img src="<?= htmlspecialchars($начинка['фото'] ?? 'assets/images/PicToppings.svg') ?>" alt="<?= htmlspecialchars($начинка['название']) ?>">
                        <h3><?= htmlspecialchars($начинка['название']) ?></h3>
                        <p><?= htmlspecialchars($начинка['описание']) ?></p>

                        <!-- Кнопки удаления и редактирования (только для роли администратора) -->
                        <?php if ($id_роли == 3): ?>
                            <div class="actions">
                                <button type="button" onclick="openEditPopup(<?= htmlspecialchars(json_encode([
                                    'id' => $начинка['id'],
                                    'название' => $начинка['название'],
                                    'описание' => $начинка['описание'],
                                    'фото' => $начинка['фото']
                                ])) ?>)">Изменить</button>

                                <form method="post" action="lib/delete_topping.php" style="display:inline;" onsubmit="return confirm('Вы уверены, что хотите удалить эту начинку?')">
                                    <input type="hidden" name="id" value="<?= $начинка['id'] ?>">
                                    <button type="submit">Удалить</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</div>
<div class="wrapper3">
    <?php if ($id_роли == 3): ?>
        <div class="wrapper3">
            <div class="container-registration">
                <h2>Добавить новую начинку</h2>
                <form method="post" action="toppings.php" enctype="multipart/form-data">
                    <input type="hidden" name="add_topping" value="1">
                    
                    <div class="inline">
                        <div>
                            <label>Название</label>
                            <input type="text" name="name" required placeholder="Введите название">
                        </div>
                        <div class="file-upload-wrapper">
                            <label>Фото</label>
                            <input type="file" name="photo" id="photo" accept="image/*" class="file-input">
                            <label for="photo" class="file-label">Выбрать картинку</label>
                        </div>
                    </div>

                    <label>Описание</label>
                    <textarea name="description" required placeholder="Введите описание начинки" class="one-line"></textarea>

                    <button type="submit">Добавить начинку</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_topping'])) {
        if ($id_роли == 3) {
            $name = trim(filter_var($_POST['name'], FILTER_SANITIZE_SPECIAL_CHARS));
            $description = trim(filter_var($_POST['description'], FILTER_SANITIZE_SPECIAL_CHARS));
            
            $photoPath = '';
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = 'uploads/toppings/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                $extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
                $filename = uniqid() . '.' . $extension;
                $photoPath = $uploadDir . $filename;
                
                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath)) {
                    $_SESSION['error'] = 'Ошибка при загрузке изображения';
                }
            }

            try {
                $sql = "INSERT INTO начинки (название, описание, фото) VALUES (?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$name, $description, $photoPath]);
                
                $_SESSION['success'] = 'Начинка успешно добавлена';
                header('Location: toppings.php');
                exit;
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Ошибка при добавлении начинки: ' . $e->getMessage();
            }
        }
    }
    ?>

    <?php require_once "blocks/footer.php"; ?>
</div>

<!-- Попап редактирования начинки -->
<div class="pop_up" id="edit_popup">
    <div class="pop_up_container">
        <div class="pop_up_body">
            <div class="pop_up_close" onclick="closeEditPopup()">×</div>
            <p>Редактировать начинку</p>
            
            <form id="edit_form" method="post" action="toppings.php" enctype="multipart/form-data">
                <input type="hidden" name="edit_topping" value="1">
                <input type="hidden" name="id" id="popup_edit_id">
                
                <div class="forms">
                    <div class="form-column">
                        <label>Название:</label>
                        <input type="text" name="name" id="popup_edit_name" required placeholder="Введите название">
                        
                        <label>Описание:</label>
                        <textarea name="description" id="popup_edit_description" required placeholder="Введите описание"></textarea>
                    </div>
                    
                    <div class="form-column">
                        <label>Текущее фото:</label>
                        <div class="current-photo">
                            <img id="popup_current_photo" src="" alt="Текущее фото начинки">
                        </div>
                        
                        <label>Заменить фото:</label>
                        <input type="file" name="photo" id="popup_edit_new_photo" accept="image/*">
                    </div>
                </div>
                
                <button type="submit">Сохранить изменения</button>
            </form>
        </div>
    </div>
</div>

<script src="js/toppings.js"></script>
</body>
</html>