<?php
session_start();
require_once 'lib/db.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

// Функция для форматирования телефона
function formatPhoneDisplay($phone) {
    if (empty($phone)) return '';
    $phone = preg_replace('/\D/', '', $phone);
    if (preg_match('/^(\d)(\d{3})(\d{3})(\d{2})(\d{2})$/', $phone, $matches)) {
        return "+{$matches[1]}({$matches[2]}){$matches[3]}-{$matches[4]}-{$matches[5]}";
    }
    return $phone;
}

// Функция для очистки телефона перед сохранением в БД
function cleanPhone($phone) {
    return preg_replace('/\D/', '', $phone);
}

// Получаем данные пользователя из базы данных
$stmt = $pdo->prepare("SELECT * FROM пользователи WHERE id = ?");
$stmt->execute([$_SESSION['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $имя = htmlspecialchars($user['имя'] ?? '');
    $фамилия = htmlspecialchars($user['фамилия'] ?? '');
    $никнейм = htmlspecialchars($user['никнейм'] ?? '');
    $телефон = formatPhoneDisplay($user['телефон'] ?? '');
    $почта = htmlspecialchars($user['почта'] ?? '');
    $дата_рождения = htmlspecialchars($user['дата_рождения'] ?? '');
    $id_адреса = $user['id_адреса'] ?? null;
}

// Получаем список адресов для выпадающего списка
$stmt = $pdo->query("
    SELECT a.id, g.название AS город, u.название AS улица, a.Номер_дома
    FROM адреса a
    JOIN улицы u ON a.id_улицы = u.id
    JOIN города g ON u.id_города = g.id
");
$адреса = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем текущий адрес пользователя
$current_address = '';
if ($id_адреса) {
    foreach ($адреса as $адрес) {
        if ($адрес['id'] == $id_адреса) {
            $current_address = "{$адрес['город']}, ул. {$адрес['улица']}, д. {$адрес['Номер_дома']}";
            break;
        }
    }
}

// Обработка формы редактирования
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $new_имя = trim($_POST['имя']);
    $new_фамилия = trim($_POST['фамилия']);
    $new_никнейм = trim($_POST['никнейм']);
    $new_телефон = cleanPhone(trim($_POST['телефон']));
    $new_почта = trim($_POST['почта']);
    $new_дата_рождения = trim($_POST['дата_рождения']);
    $new_id_адреса = intval($_POST['адрес_доставки']);

    // Обновляем данные в базе
    $stmt = $pdo->prepare("
        UPDATE пользователи SET 
            имя = ?, 
            фамилия = ?, 
            никнейм = ?, 
            телефон = ?, 
            почта = ?, 
            дата_рождения = ?, 
            id_адреса = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $new_имя, $new_фамилия, $new_никнейм, $new_телефон, 
        $new_почта, $new_дата_рождения, $new_id_адреса, 
        $_SESSION['id']
    ]);

    // Обновляем данные в сессии
    $_SESSION['имя'] = $new_имя;
    $_SESSION['фамилия'] = $new_фамилия;
    $_SESSION['никнейм'] = $new_никнейм;
    $_SESSION['телефон'] = $new_телефон;
    $_SESSION['почта'] = $new_почта;
    $_SESSION['дата_рождения'] = $new_дата_рождения;
    $_SESSION['id_адреса'] = $new_id_адреса;

    // Перенаправляем, чтобы избежать повторной отправки формы
    header('Location: user.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="css/main.css" type="text/css"/> 
    <link rel="stylesheet" href="css/footer.css" type="text/css"/>
    <link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <link rel="stylesheet" href="css/registration.css" type="text/css"/>
    <link rel="stylesheet" href="css/user.css" type="text/css"/>
    <link rel="stylesheet" href="css/popup.css" type="text/css"/>
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once "blocks/header.php"; ?>
        
        <div class="user-container">
            <h1>Профиль</h1>

            <div class="user-header">
                <div class="user-name">
                    <p>Привет, <b><?= $имя ?: 'Гость' ?> <?= $фамилия ?></b></p>
                    <p><b>@<?= $никнейм ?></b></p>
                </div>
                <button class="btn-edit" id="open_edit_popup">Редактировать профиль</button>
            </div>

            <div class="user-info">
                <div class="user-text">
                    <h3>Адрес доставки:</h3>
                    <p><?= $current_address ?: 'Не указан' ?></p>
                </div>

                <div class="user-text">
                    <h3>Почта:</h3>
                    <p><?= $почта ?></p>
                </div>

                <div class="user-text">
                    <h3>Дата рождения:</h3>
                    <p><?= $дата_рождения ?></p>
                </div>

                <div class="user-text">
                    <h3>Телефон:</h3>
                    <p><?= $телефон ?></p>
                </div>
            </div>

            <a href="lib/logout.php" class="exit">Выйти</a>
        </div>
    </div>

    <!-- Попап для редактирования профиля -->
    <div class="pop_up" id="edit_popup">
        <div class="pop_up_container">
            <div class="pop_up_body">
                <p>Редактирование профиля</p>
                <form method="post" action="">
                    <div class="forms">
                        <div class="form-column">
                            <label for="имя">Имя:</label>
                            <input type="text" name="имя" placeholder="Имя" value="<?= $имя ?>" required>
                            <label for="фамилия">Фамилия:</label>
                            <input type="text" name="фамилия" placeholder="Фамилия" value="<?= $фамилия ?>">
                            <label for="никнейм">Никнейм:</label>
                            <input type="text" name="никнейм" placeholder="Никнейм" value="<?= $никнейм ?>" required>
                            <label for="дата_рождения">Дата рождения:</label>
                            <input type="date" name="дата_рождения" value="<?= $дата_рождения ?>">
                            
                        </div>
                        <div class="form-column">
                            <label for="телефон">Телефон:</label>
                            <input type="tel" name="телефон" id="телефон" 
                                   placeholder="+7(XXX)XXX-XX-XX"
                                   value="<?= $телефон ?>" required
                                   pattern="\+7\(\d{3}\)\d{3}-\d{2}-\d{2}">
                            <label for="почта">Почта:</label>
                            <input type="email" name="почта" placeholder="Почта" value="<?= $почта ?>" required>
                            <label for="адрес_доставки">Адрес доставки:</label>
                            <select name="адрес_доставки" id="адрес_доставки" required>
                                <option value="">Выберите адрес доставки</option>
                                <?php foreach ($адреса as $адрес): ?>
                                    <option value="<?= $адрес['id'] ?>" <?= ($адрес['id'] == $id_адреса) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars("{$адрес['город']}, ул. {$адрес['улица']}, д. {$адрес['Номер_дома']}") ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn-save">Сохранить изменения</button>
                </form>
                <div class="pop_up_close" id="close_edit_popup">&#10006;</div>
            </div>
        </div>
    </div>
    <?php require_once "blocks/footer.php"; ?>
    <script src="js/user.js"></script>
</body>
</html>