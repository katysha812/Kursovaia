<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Контакты</title>
    <Link rel="stylesheet" href="css/main.css" type="text/css"/>
    <Link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <Link rel="stylesheet" href="css/footer.css" type="text/css"/>
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once "blocks/header.php"; ?>
         <!-- Контактная информация -->
        <div class="container-contacts">
            <h2>Контакты</h2>
            <div class="contacts-info">
                <div class="contacts-text">
                    <p>
                        <a class="contact-link" href="tel:+70000000000">
                            +7 (000) 000-000-00
                        </a>
                    </p>
                    <p>Пн-Вс: с 10:00 до 21:00</p>
                    <p>
                        <a class="contact-link" href="https://mail.google.com/">
                            mail-company@mail.ru
                        </a>
                    </p>

                        <div class="Pics">
                        <a href="https://vk.com/" target="_blank">
                            <img src="assets/images/Contacts11.svg" alt="VK">
                        </a>
                        <a href="https://www.tiktok.com/explore" target="_blank">
                            <img src="assets/images/Contacts22.svg" alt="TT">
                        </a>
                        <a href="https://web.telegram.org/k/" target="_blank">
                            <img src="assets/images/Contacts33.svg" alt="TG">
                        </a>
                    </div>

                    <p>Мы находимся по адресу:</p>
                    <p>
                        <a class="contact-link" href="https://yandex.ru/maps/1095/abakan/?ll=91.442387%2C53.721152&z=13" target="_blank">
                            г. Город, ул Уличная, дом 0, корп 0, офис 0
                        </a>
                    </p>

                </div>
                <a href="https://yandex.ru/maps/1095/abakan/?ll=91.442387%2C53.721152&z=13" target="_blank">
                    <img class="pic-contacts" src="assets/images/ContactsPic2.svg" alt="Карта">
                </a>
            </div>
            
        </div>
    </div>
    <?php require_once "blocks/footer.php"; ?>
</body>
</html>