<?php 
session_start();
require_once 'lib/db.php';

$isAdmin = isset($_SESSION['id_роли']) && $_SESSION['id_роли'] == 3;

try {
    $sql = "SELECT id, фото, название, описание, цена_кг FROM торты";
    $stmt = $pdo->query($sql);
    $торты = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка при получении тортов: " . $e->getMessage());
}

if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add_cake') {
            $название = trim($_POST['название'] ?? '');
            $описание = trim($_POST['описание'] ?? '');
            $цена_кг = isset($_POST['цена_кг']) ? (float)str_replace(',', '.', $_POST['цена_кг']) : 0;
            
            if (empty($название)) {
                throw new Exception("Название торта обязательно для заполнения");
            }
            if (empty($описание)) {
                throw new Exception("Описание торта обязательно для заполнения");
            }
            if ($цена_кг <= 0) {
                throw new Exception("Цена должна быть больше нуля");
            }

            if (!isset($_FILES['фото']) || $_FILES['фото']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('Необходимо загрузить фото торта');
            }

            $uploadDir = 'uploads/cakes/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $extension = pathinfo($_FILES['фото']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $extension;
            $фото = $uploadDir . $filename;
            
            if (!move_uploaded_file($_FILES['фото']['tmp_name'], $фото)) {
                throw new Exception('Ошибка при загрузке изображения');
            }

            $stmt = $pdo->prepare("INSERT INTO торты (название, описание, фото, цена_кг) VALUES (?, ?, ?, ?)");
            $stmt->execute([$название, $описание, $фото, $цена_кг]);
            $_SESSION['success'] = 'Торт успешно добавлен';
            
        } elseif ($action === 'update_cake') {
            $id = (int)($_POST['cake_id'] ?? 0);
            $название = trim($_POST['название'] ?? '');
            $описание = trim($_POST['описание'] ?? '');
            $цена_кг = isset($_POST['цена_кг']) ? (float)str_replace(',', '.', $_POST['цена_кг']) : 0;

            if ($id <= 0) {
                throw new Exception("Неверный ID торта");
            }
            if (empty($название)) {
                throw new Exception("Название торта обязательно для заполнения");
            }
            if (empty($описание)) {
                throw new Exception("Описание торта обязательно для заполнения");
            }
            if ($цена_кг <= 0) {
                throw new Exception("Цена должна быть больше нуля");
            }

            $stmt = $pdo->prepare("SELECT фото FROM торты WHERE id = ?");
            $stmt->execute([$id]);
            $current = $stmt->fetch();
            $фото = $current['фото'] ?? '';

            if (isset($_FILES['фото']) && $_FILES['фото']['error'] === UPLOAD_ERR_OK) {
                if ($фото && file_exists($фото)) {
                    unlink($фото);
                }
                
                $uploadDir = 'uploads/cakes/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                $extension = pathinfo($_FILES['фото']['name'], PATHINFO_EXTENSION);
                $filename = uniqid() . '.' . $extension;
                $фото = $uploadDir . $filename;
                
                if (!move_uploaded_file($_FILES['фото']['tmp_name'], $фото)) {
                    throw new Exception('Ошибка при загрузке изображения');
                }
            }

            $stmt = $pdo->prepare("UPDATE торты SET название = ?, описание = ?, фото = ?, цена_кг = ? WHERE id = ?");
            $stmt->execute([$название, $описание, $фото, $цена_кг, $id]);
            $_SESSION['success'] = 'Торт успешно обновлен';
            
        } elseif ($action === 'delete_cake') {
            $id = (int)($_POST['cake_id'] ?? 0);
            
            if ($id <= 0) {
                throw new Exception("Неверный ID торта");
            }

            $stmt = $pdo->prepare("SELECT фото FROM торты WHERE id = ?");
            $stmt->execute([$id]);
            $current = $stmt->fetch();
            $фото = $current['фото'] ?? '';

            $stmt = $pdo->prepare("DELETE FROM торты WHERE id = ?");
            $stmt->execute([$id]);

            if ($фото && file_exists($фото)) {
                unlink($фото);
            }

            $_SESSION['success'] = 'Торт успешно удален';
        }
        
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
        
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Торты на заказ</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/contacts.css">
    <link rel="stylesheet" href="css/toppings.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/popup.css">
    <link rel="stylesheet" href="css/registration.css">
    <link rel="stylesheet" href="css/customcakes.css">
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once "blocks/header.php"; ?>
        
        <!-- Вывод сообщений об ошибках/успехе -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message"><?= htmlspecialchars($_SESSION['error']) ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="success-message"><?= htmlspecialchars($_SESSION['success']) ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <div class="wrapper">
            <!-- Популярные торты -->
            <div class="container-cakes">
                <h1>Наши работы</h1>
                
                <div class="cards-cakes">
                    <?php foreach ($торты as $торт): ?>
                    <div class="card-cake">
                        <div class="cake block">
                            <img src="<?= htmlspecialchars($торт['фото'] ?: 'images/default-cake.jpg') ?>" 
                                 alt="<?= htmlspecialchars($торт['название']) ?>">
                            <h3><?= htmlspecialchars($торт['название']) ?></h3>
                            <p><?= htmlspecialchars($торт['описание']) ?></p>
                            <a href="Cake.php?id=<?= $торт['id'] ?>">
                                <button class="btn">Подробнее</button>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
<!-- Блок управления для администратора -->
<?php if ($isAdmin): ?>
<div class="wrapper3">
    
    <div class="container-registration">
        <h2>Управление тортами (админ)</h2>
        <!-- Селектор действия -->
        <div class="form-group">
            <label for="actionSelect">Действие:</label>
            <select id="actionSelect" onchange="toggleAdminForm()" required>
                <option value="">Выберите действие</option>
                <option value="add_cake">Добавить торт</option>
                <option value="update_cake">Редактировать торт</option>
                <option value="delete_cake">Удалить торт</option>
            </select>
        </div>
        <!-- Форма для добавления -->
        <form id="addForm" method="post" enctype="multipart/form-data" style="display:none;" class="admin-subform">
            <input type="hidden" name="action" value="add_cake">
            
            <div class="form-group">
                <label for="add_name">Название:</label>
                <input type="text" id="add_name" name="название" required>
            </div>
            <div class="form-group">
                <label for="add_desc">Описание:</label>
                <input id="add_desc" name="описание" required class="one-line"></input>
            </div>
            <div class="form-group">
                <label for="add_price">Цена за кг (руб):</label>
                <input type="number" id="add_price" name="цена_кг" min="999.00" step="100.0" required>
            </div>
            <div class="form-group">
                <label for="add_photo">Фото:</label>
                <div class="file-upload-wrapper">
                    <input type="file" id="add_photo" name="фото" class="file-input" accept="image/*" required>
                    <label for="add_photo" class="file-label">Выбрать картинку</label>
                </div>
            </div>
            <button type="submit" class="btn">Добавить</button>
        </form>
        
        <!-- Форма для редактирования -->
        <form id="updateForm" method="post" enctype="multipart/form-data" style="display:none;" class="admin-subform">
            <input type="hidden" name="action" value="update_cake">
            
            <div class="form-group">
                <label for="update_cake_id">Выберите торт:</label>
                <select id="update_cake_id" name="cake_id" required>
                    <?php foreach ($торты as $торт): ?>
                        <option value="<?= $торт['id'] ?>"><?= htmlspecialchars($торт['название']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="update_name">Новое название:</label>
                <input type="text" id="update_name" name="название" required>
            </div>
            <div class="form-group">
                <label for="update_desc">Новое описание:</label>
                <input id="update_desc" name="описание" required class="one-line"></input>
            </div>
            <div class="form-group">
                <label for="update_price">Новая цена за кг (руб):</label>
                <input type="number" id="update_price" name="цена_кг" min="0.01" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="update_photo">Новое фото (оставьте пустым, чтобы не менять):</label>
                <div class="file-upload-wrapper">
                    <input type="file" id="update_photo" name="фото" class="file-input" accept="image/*">
                    <label for="update_photo" class="file-label">Выбрать картинку</label>
                </div>
            </div>
            <button type="submit" class="btn">Обновить</button>
        </form>
        
        <!-- Форма для удаления -->
        <form id="deleteForm" method="post" style="display:none;" class="admin-subform">
            <input type="hidden" name="action" value="delete_cake">
            
            <div class="form-group">
                <label for="delete_cake_id">Выберите торт для удаления:</label>
                <select id="delete_cake_id" name="cake_id" required>
                    <?php foreach ($торты as $торт): ?>
                        <option value="<?= $торт['id'] ?>"><?= htmlspecialchars($торт['название']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-danger">Удалить</button>
        </form>
        
        
    </div>
</div>

<script src="js/customcakes.js"></script>
<?php endif; ?>

</body>
</html>