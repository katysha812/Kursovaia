<?php
require "lib/db.php"; // Подключение к БД

// Запрос для получения всех адресов с городом и улицей
$sql = "
    SELECT 
        a.id,
        c.название AS город,
        b.название AS улица,
        a.Номер_дома
    FROM адреса a
    LEFT JOIN улицы b ON a.id_улицы = b.id
    LEFT JOIN города c ON b.id_города = c.id
";

$stmt = $pdo->query($sql);
$адреса = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <Link rel="stylesheet" href="css/main.css" type="text/css"/>
    <Link rel="stylesheet" href="css/registration.css" type="text/css"/>
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once "blocks/header.php"; ?>

        <div class="wrapper3">
            <div class="container-registration">
                <h2>Регистрация</h2>
                <p>Займите себе местечко в сладком раю</p>
                <form method="post" action="lib/reg.php">
                    <label>Фамилия</label>
                    <input type="text" class="one-line" name="user_first_name">

                    <label>Имя</label>
                    <input type="text" class="one-line" name="user_name">

                    <label>Телефон</label>
                    <input type="tel" class="one-line" name="user_number" placeholder="+7 (000) 000-00-00">

                    <label>Почта</label>
                    <input type="email" class="one-line" name="user_email">

                    <label>Дата рождения</label>
                    <input type="date" class="one-line" name="user_dateborn">

                    <label>Адрес доставки</label>
                    <select name="user_adress" required>
                        <option value="">Выберите адрес</option>
                        <?php foreach ($адреса as $адрес): ?>
                            <option value="<?= htmlspecialchars($адрес['id']) ?>">
                                <?= htmlspecialchars("{$адрес['город']}, ул. {$адрес['улица']}, д. {$адрес['Номер_дома']}") ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <div class="inline">
                        <div>
                            <label>Никнейм</label>
                            <input type="text" name="user_nickname">
                        </div>
                        <div>
                            <label>Пароль</label>
                            <input type="password" name="user_password">
                        </div>
                    </div>
                    <a href="Login.php">Уже есть аккаунт</a>
                    <button type="submit">Зарегистрироваться</button>
                    
                </form>
            </div>
        </div>
    </div>
    <script src="js/reg.js"></script>
</body>
</html>
