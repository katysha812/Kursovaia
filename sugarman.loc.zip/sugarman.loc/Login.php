<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <Link rel="stylesheet" href="css/main.css" type="text/css"/>
    <Link rel="stylesheet" href="css/registration.css" type="text/css"/>
    <Link rel="stylesheet" href="css/contacts.css" type="text/css"/>
    <Link rel="stylesheet" href="css/popup.css" type="text/css"/>
</head>
<body>
    <div class="wrapper">
        <!-- Шапка сайта -->
        <?php require_once "blocks/header.php"; ?>

        <div class="wrapper3">
            <div class="container-registration">
                <h2>Вход</h2>
                <p>Введите данные и войдите в свой пряничный домик</p>

                <?php if (isset($_SESSION['reset_success'])): ?>
                    <div class="reset-message reset-success"><?= $_SESSION['reset_success'] ?></div>
                    <?php unset($_SESSION['reset_success']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['reset_error'])): ?>
                    <div class="reset-message reset-error"><?= $_SESSION['reset_error'] ?></div>
                    <?php unset($_SESSION['reset_error']); ?>
                <?php endif; ?>

                <form method="post" action="lib/login.php">
                    <label>Никнейм</label>
                    <input type="text" class="one-line" name="user_nickname" required>

                    <label>Пароль</label>
                    <input type="password" class="one-line" name="user_password" required>

                    <a href="#" id="open_pop_up2" >Забыли пароль?</a>
                    
                    <button type="submit">Войти</button>
                    <a class="no-login" href="Registration.php">У меня еще нет аккаунта</a>
                </form>
            </div>
        </div>

        <div class="pop_up" id="pop_up2">
            <div class="pop_up_container">
                <div class="pop_up_body">
                    <h2>Восстановление пароля</h2>
                    
                    <div class="restore-message">
                        Обратитесь к администратору
                    </div>
                    
                    <a href="Contacts.php" class="restore-button">Соцсети</a>
                    
                    <div class="pop_up_close" id="close_pop_up2">&#10006</div>
                </div>
            </div>
        </div>
    </div>
<script src="js/login.js"></script>
</body>
</html>
